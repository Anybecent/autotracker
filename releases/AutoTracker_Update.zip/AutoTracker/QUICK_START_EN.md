# 🎯 AutoTracker Pro — Quick Start Guide

**AutoTracker Pro** is a professional CEP extension for Adobe Premiere Pro that provides fast, reliable automated motion tracking of moving objects in your video without tedious frame-by-frame manual keyframing on the timeline. It automatically generates smooth **Position** keyframes on any target layer or centers your sequence viewport directly around a tracked subject.

---

## 1. System Requirements

| Component | Requirement |
|---|---|
| **Adobe Premiere Pro** | 2020, 2021, 2022, 2023, 2024, 2025, 2026+ (versions 14.0 – 26.x+) |
| **Operating System** | Windows 10 or Windows 11 (64-bit only) |
| **System Memory (RAM)** | 8 GB minimum (16 GB recommended for 4K video editing) |
| **Graphics Card (GPU)** | Any modern DirectX 12 / WebGPU-capable GPU (NVIDIA, AMD, Intel). If a compatible GPU is not present, the multi-threaded WASM SIMD CPU engine is automatically utilized |
| **External Utilities** | All dependencies (FFmpeg static binary, OpenCV WebAssembly, ONNX Runtime Web) are **pre-bundled in the release distribution** — no manual downloads required |

---

## 2. Plugin Installation

### Method 1: One-Click Automated Installer (Recommended)
1. Completely close **Adobe Premiere Pro** if running.
2. Unpack the downloaded `AutoTracker_v1.0.0_Win.zip` archive to any directory.
3. Run **`install.bat`** (double-click or right-click -> *"Run as administrator"*).
4. The installer script will automatically:
   - Verify file package integrity.
   - Configure the required Windows Registry flags (`PlayerDebugMode` for CSXS 7–18).
   - Deploy the extension directly into Premiere Pro's CEP directory:  
     `%APPDATA%\Adobe\CEP\extensions\AutoTracker`
5. Press any key when prompted to complete the installation.

### Method 2: Manual Installation
1. Close Premiere Pro.
2. Press `Win + R`, type `regedit` and hit `Enter`.
3. Navigate to: `HKEY_CURRENT_USER\Software\Adobe\`
4. In each available key `CSXS.9`, `CSXS.10`, `CSXS.11`, `CSXS.12`, `CSXS.13`, `CSXS.14`, `CSXS.15`, `CSXS.16`, ensure a String value named **`PlayerDebugMode`** is set to **`1`**.
5. Copy all plugin files into:  
   `C:\Users\<Your_Username>\AppData\Roaming\Adobe\CEP\extensions\AutoTracker\`

### How to open AutoTracker in Premiere Pro:
1. Launch Adobe Premiere Pro and open any project.
2. In the top application menu bar, go to:  
   **Window** > **Extensions** > **Auto-Tracker**.
3. Dock the panel anywhere in your workspace (such as beside *Effect Controls* or the *Tools* toolbar).

---

## 3. License Key Activation

To unlock unlimited tracking and all professional features:

1. Click the golden key icon **🔑** (*"License Management"*) in the top-right corner of the panel header.
2. Enter your unique license key (format: `ATPRO-XXXX-XXXX-XXXX-XXXX` or your Lemon Squeezy order license key).
3. Click **"Activate"**.
4. The plugin will verify cryptographic authenticity (HMAC-SHA256 signature) and persist your activation.
5. The status badge will switch to green *"License Active"* displaying your license tier (*Lifetime* or subscription period).
6. **Transferring to another computer**: If upgrading machines, open the license modal, click **"Deactivate"**, and reuse your key on the new computer.

---

## 4. Step-by-Step Workflow (Operation Modes)

The plugin provides two primary workflow modes accessible via the top tabs:

```
[ Attach Layer (Прив'язка шару) ]   |   [ Center on Point (Lock-on Center) ]
```

---

### Mode A: Attach Layer Mode
*Use this mode to pin text titles, callouts, speech bubbles, stickers, arrows, logos, or overlay clips to moving objects in your footage without manually setting keyframes frame by frame.*

1. **Step 1. Load Source Clip**:
   - On the timeline, select the video clip containing the moving subject.
   - In the **Source Clip** section, click **"Load Selected Clip"**.
   - Clip metadata (FPS, duration, filename) and the current playhead frame will appear in the preview window.

2. **Step 2. Select Target Subject**:
   - **Point Mode (◉)** (Default): Click directly on a distinct detail of the object in 1 click (e.g., eye, button, vehicle headlight, logo). A target marker will appear with an inner *Feature Box* and outer *Search Box*.
   - **Area Mode (☐)**: Click the **"Area"** button and draw a rectangular bounding box (ROI) around the subject.

3. **Step 3. Load Target Layer**:
   - On the timeline, select the layer you want to follow the tracked object (text layer, graphic, nested sequence, or overlay).
   - In the **Target Layer** section, click **"Load Selected Layer"**.
   - The panel confirms the layer name and timeline track (e.g., `Title 1 (Video 2)`).

4. **Step 4. Start Tracking**:
   - Click **"Start Tracking"**.
   - AutoTracker analyzes the object's movement frame by frame and displays real-time progress.
   - Smooth **Position** keyframes are automatically written into the target layer's *Motion* component. Play back your sequence in the Program Monitor to see the result!

---

### Mode B: Center on Point (Lock-on Center)
*A dynamic stabilization mode where the selected point or area is kept locked at the exact center of the sequence frame, creating the popular "camera locked onto subject" effect.*

1. Switch to the **"Center on Point"** tab at the top of the panel.
2. Select your video clip on the timeline and click **"Load Selected Clip"**.
3. **No separate target layer is required!** Keyframes are applied directly to the source clip with automatic sequence aspect and resolution alignment.
4. Pick your target in **Point (◉)** mode or draw a box in **Area (☐)** mode on the desired focal subject (athlete's face, sports ball, vehicle emblem).
5. Click **"Start Tracking"**.
6. The plugin calculates the compensating center offsets and writes **Position** keyframes directly onto your source clip so the subject stays locked in the center of the screen.

---

## 5. Preview Controls, Settings & Customization

### Preview Window Navigation (Zoom, Pan & Refresh Frame):
Use the toolbar right above the preview canvas for comfortable target selection:
- **Zoom Buttons**: Use **`+`** (zoom in), **`−`** (zoom out), **`1:1`** (100% original pixel size), and **`Fit`** (fit the entire frame into the preview window).
- **Mouse Wheel Zoom**: Scroll the mouse wheel directly over the preview canvas to zoom in or out around your cursor.
- **Canvas Panning (`Space + Drag`)**: Hold the **`Spacebar`** and drag with your mouse (or drag using the middle/right mouse button) to pan across the zoomed frame.
- **`⟳ Refresh Frame` Button**: If you move the Premiere Pro timeline playhead (CTI) to a new position, click **`⟳ Refresh Frame`** to immediately load the frame at the current cursor position.

---

### Object Type Selector & Silhouette Mode:
Inside the **"Advanced Settings"** section, choose the best detection mode in the **"Object Type"** dropdown:
- **Auto (Recommended)** — Versatile tracking mode suitable for most everyday video clips.
- **Silhouette (Fingers, Cartoons, Flat shapes)** — Dedicated mode designed for uniform, low-texture objects such as fingertips, hand gestures, cartoons, 2D animations, and flat graphic shapes. Selecting this mode reveals the **"Silhouette Tolerance"** slider (default: `50`) to fine-tune contour sensitivity.
- **Textured (Classic)** — Optimized for subjects with clear surface details and high-contrast patterns.

---

### Flexible Tracking Settings:
- **Track from playhead (CTI)** — Starts tracking from the current timeline cursor position to the end of the clip instead of from the very first frame. Ideal when your subject enters the frame mid-clip.
- **Keyframe step (Every frame, Every 2 frames, Every 5 frames)** — Choose how frequently keyframes are generated: every frame for maximum accuracy, or every 2 or 5 frames for faster processing and easier manual tweaks.
- **Smoothing** — Automatically smooths the tracked trajectory to remove micro-jitter and produce natural motion.
- **Feature Box & Search Box Sliders**:
  - **Feature Box Size** (`24 px` to `160 px`, default `48 px`) — Controls the size of the inner target box being tracked.
  - **Search Box Size** (`64 px` to `320 px`, default `128 px`) — Controls the size of the outer search area where the tracker looks for the object in the next frame (increase this value for fast-moving subjects).

---

### Dark / Light Theme & Language Switcher (UA / EN):
In the top-right header of the AutoTracker panel, you can customize the interface at any time:
- **Theme Toggle (`🌙` / `☀️`)** — Instantly switch between **Dark** and **Light** themes to match your Premiere Pro workspace.
- **Language Toggle (`UA` / `EN`)** — Switch the entire plugin interface between **Ukrainian** and **English** with a single click.

---

## 6. Troubleshooting & FAQ

### ❓ Error: `STILL_IMAGE_NEST_REQUIRED` when tracking still pictures (.png, .jpg)
**Cause**: Adobe Premiere Pro's ExtendScript API restricts direct keyframe creation on raw still image clips on the timeline.  
**Solution**:
1. On the Premiere Pro timeline, right-click the image clip.
2. Select **"Nest..."** and press OK.
3. Select the resulting nested sequence on the timeline and click **"Load Selected Layer"** in AutoTracker.
4. Start tracking — keyframes will now apply seamlessly!

---

### ❓ Error: `NO_SEQUENCE` or `NO_CLIP_FOUND`
**Cause**: The timeline sequence is not active or no clip was selected.  
**Solution**: Click anywhere inside the Premiere Pro timeline to make it active (blue/gray outline), park the CTI over the desired clip, click the clip to select it, and press *"Load Selected Clip"*.

---

### ❓ Tracking loses target on challenging footage
**Solutions**:
- **Fast motion**: Open *"Advanced Settings"* and increase the **"Search Box"** slider (e.g., from `128 px` to `200–280 px`).
- **Uniform / Flat surface**: In the **"Object Type"** dropdown, switch to **"Silhouette (Fingers, Cartoons, Flat shapes)"**.
- **Heavy motion blur**: Select the entire object using **"Area (☐)"** mode or increase the **"Feature Box"** size, and make sure **"Smoothing"** is enabled.

---

### ❓ White or empty screen on opening plugin panel
**Solution**:
1. Run `install.bat` to configure registry flags automatically.
2. If manually installing, verify `PlayerDebugMode=1` is present in `HKEY_CURRENT_USER\Software\Adobe\CSXS.11` (or matching CSXS version).
3. Restart Premiere Pro.

---

### ❓ Where are diagnostic logs located for support?
AutoTracker writes technical diagnostic logs to:  
`%TEMP%\autotracker.log`  
*(Press `Win + R`, type `%TEMP%` and look for `autotracker.log`).*

---

*Thank you for choosing AutoTracker Pro! Happy editing!*
