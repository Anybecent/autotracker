// hostscript.jsx - ExtendScript (ES3) for Auto-Tracker CEP Plugin
// Pure ES3 compatible

// =========================================================================
// Embedded json2.js (Douglas Crockford, Public Domain)
// Pure ES3 JSON polyfill — zero external dependencies
// =========================================================================
var JSON;
if (!JSON) {
    JSON = {};
}
(function () {
    'use strict';

    var rx_one = /^[\],:{}\s]*$/;
    var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
    var rx_three = /(?:"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g;
    var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
    var rx_escapable = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

    function f(n) {
        return n < 10 ? '0' + n : n;
    }

    function this_value() {
        return this.valueOf();
    }

    if (typeof Date.prototype.toJSON !== 'function') {
        Date.prototype.toJSON = function () {
            return isFinite(this.valueOf())
                ? this.getUTCFullYear() + '-' +
                        f(this.getUTCMonth() + 1) + '-' +
                        f(this.getUTCDate()) + 'T' +
                        f(this.getUTCHours()) + ':' +
                        f(this.getUTCMinutes()) + ':' +
                        f(this.getUTCSeconds()) + 'Z'
                : null;
        };
        Boolean.prototype.toJSON  = this_value;
        Number.prototype.toJSON   = this_value;
        String.prototype.toJSON   = this_value;
    }

    var gap;
    var indent;
    var meta;
    var rep;

    function quote(string) {
        rx_escapable.lastIndex = 0;
        return rx_escapable.test(string) ? '"' + string.replace(rx_escapable, function (a) {
            var c = meta[a];
            return typeof c === 'string' ? c : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
        }) + '"' : '"' + string + '"';
    }

    function str(key, holder) {
        var i;
        var k;
        var v;
        var length;
        var mind = gap;
        var partial;
        var value = holder[key];

        if (value && typeof value === 'object' && typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }
        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }
        switch (typeof value) {
        case 'string':
            return quote(value);
        case 'number':
            return isFinite(value) ? String(value) : 'null';
        case 'boolean':
        case 'null':
            return String(value);
        case 'object':
            if (!value) { return 'null'; }
            gap += indent;
            partial = [];
            if (Object.prototype.toString.apply(value) === '[object Array]') {
                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }
                v = partial.length === 0 ? '[]' : gap ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']' : '[' + partial.join(',') + ']';
                gap = mind;
                return v;
            }
            if (rep && typeof rep === 'object') {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    if (typeof rep[i] === 'string') {
                        k = rep[i];
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            } else {
                for (k in value) {
                    if (Object.prototype.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            }
            v = partial.length === 0 ? '{}' : gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}' : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
        }
    }

    if (typeof JSON.stringify !== 'function') {
        meta = {
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"': '\\"',
            '\\': '\\\\'
        };
        JSON.stringify = function (value, replacer, space) {
            var i;
            gap = '';
            indent = '';
            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) { indent += ' '; }
            } else if (typeof space === 'string') {
                indent = space;
            }
            rep = replacer;
            if (replacer && typeof replacer !== 'function' && (typeof replacer !== 'object' || typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }
            return str('', {'': value});
        };
    }

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text, reviver) {
            var j;
            function walk(holder, key) {
                var k;
                var v;
                var value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver ? reviver.call(holder, key, value) : value;
            }
            text = String(text);
            rx_dangerous.lastIndex = 0;
            if (rx_dangerous.test(text)) {
                text = text.replace(rx_dangerous, function (a) {
                    return '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }
            if (rx_one.test(text.replace(rx_two, '@').replace(rx_three, ']').replace(rx_four, ''))) {
                j = eval('(' + text + ')');
                return typeof reviver === 'function' ? walk({'': j}, '') : j;
            }
            throw new SyntaxError('JSON.parse');
        };
    }
}());
if (typeof $ !== 'undefined' && $.global && !$.global.JSON) {
    $.global.JSON = JSON;
}

function _v(val) {
    if (val === null || val === undefined) return 'null';
    if (typeof val === 'boolean') return String(val);
    if (typeof val === 'number') return (!isFinite(val) || isNaN(val)) ? 'null' : String(val);
    if (typeof val === 'string') {
        return '"' + val.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
                        .replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
    }
    if (val instanceof Array || Object.prototype.toString.call(val) === '[object Array]') {
        var items = [];
        for (var ai = 0; ai < val.length; ai++) items.push(_v(val[ai]));
        return '[' + items.join(',') + ']';
    }
    var parts = [];
    for (var k in val) {
        if (val.hasOwnProperty(k)) parts.push('"' + k + '":' + _v(val[k]));
    }
    return '{' + parts.join(',') + '}';
}

// Справжнє скінченне число. Не можна покладатися на isFinite(): isFinite(null) === true,
// а NaN/Infinity після JSON-серіалізації перетворюються на null.
function _isNum(v) {
    return typeof v === 'number' && isFinite(v);
}

function _err(code, detail) {
    return _v({ error: code, detail: detail || '' });
}

function _parse(jsonStr) {
    if (!jsonStr) return null;
    jsonStr = String(jsonStr).replace(/[\u2028\u2029]/g, '');
    if (jsonStr.length > 2048) {
        try {
            return eval('(' + jsonStr + ')');
        } catch (eFast) {}
    }
    try {
        if (typeof JSON !== 'undefined' && JSON.parse) {
            return JSON.parse(jsonStr);
        }
    } catch (ej) {}
    try {
        return eval('(' + jsonStr + ')');
    } catch(e) {
        return null;
    }
}

function _cleanMediaPath(raw) {
    if (!raw) return "";
    var s = String(raw);
    try { s = decodeURI(s); } catch (e) {}
    s = s.replace(/^file:\/\/localhost\//i, '/');
    s = s.replace(/^file:\/\/\/?([a-zA-Z]:)/i, '$1');
    s = s.replace(/^file:\/{1,3}/i, '/');
    s = s.replace(/^\/([a-zA-Z]:)/, '$1');
    return s;
}

function _getMotionComponentAndProps(clip) {
    var motionComp = null;
    var posProp = null;
    var scaleProp = null;
    var scaleWidthProp = null;
    var uniformScaleProp = null;
    var rotProp = null;
    var anchorProp = null;
    if (!clip) return { motionComp: null, posProp: null, scaleProp: null, scaleWidthProp: null, uniformScaleProp: null, rotProp: null, anchorProp: null };
    try {
        var comps = clip.components;
        if (comps) {
            var numComps = (comps.numItems !== undefined) ? comps.numItems : (comps.length || 0);
            for (var c = 0; c < numComps; c++) {
                var comp = comps[c];
                var mName = "";
                var dName = "";
                try { if (comp.matchName) mName = comp.matchName; } catch (em) {}
                try { if (comp.displayName) dName = comp.displayName; } catch (ed) {}
                if (mName === "ADBE Motion" || mName === "AE.ADBE Motion" || mName.indexOf("Motion") !== -1 ||
                    dName === "Motion" || dName === "Trajectoire" || dName === "Bewegung" ||
                    dName === "Movimiento" || dName === "Movimento" || dName === "Рух" ||
                    dName === "Позиція" || dName === "Положення" ||
                    dName === "モーション" || dName === "运动") {
                    motionComp = comp;
                    break;
                }
            }
            if (!motionComp && numComps > 0) {
                motionComp = comps[0];
            }
        }
    } catch (eComp) {}

    if (motionComp) {
        try {
            var props = motionComp.properties;
            if (props) {
                var numProps = (props.numItems !== undefined) ? props.numItems : (props.length || 0);
                for (var p = 0; p < numProps; p++) {
                    var prop = props[p];
                    var pmName = "";
                    var pdName = "";
                    try { if (prop.matchName) pmName = prop.matchName; } catch (epm) {}
                    try { if (prop.displayName) pdName = prop.displayName; } catch (epd) {}

                    if (pmName === "ADBE Position" || pmName.indexOf("Position") !== -1 ||
                        pdName === "Position" || pdName === "Posición" || pdName === "Posizione" ||
                        pdName === "Позиція" || pdName === "Положення" || pdName === "位置") {
                        posProp = prop;
                    }

                    var isWidth = (pmName === "ADBE Scale Width" || pmName.indexOf("Width") !== -1 ||
                                   pdName.indexOf("Width") !== -1 || pdName.indexOf("Largeur") !== -1 ||
                                   pdName.indexOf("Breite") !== -1 || pdName.indexOf("Anchura") !== -1 ||
                                   pdName.indexOf("Ширин") !== -1);
                    var isUniform = (pmName === "ADBE Uniform Scale" || pmName.indexOf("Uniform") !== -1 ||
                                     pdName.indexOf("Uniform") !== -1 || pdName.indexOf("Gleichmäßig") !== -1 ||
                                     pdName.indexOf("Рівномірн") !== -1);

                    if (isWidth) {
                        scaleWidthProp = prop;
                    } else if (isUniform) {
                        uniformScaleProp = prop;
                    } else if (pmName === "ADBE Scale" ||
                               ((pmName.indexOf("Scale") !== -1 || pdName === "Scale" || pdName === "Échelle" ||
                                 pdName === "Skalieren" || pdName === "Escala" || pdName === "Scala" ||
                                 pdName === "Масштаб" || pdName === "スケール" || pdName === "缩放") && !isWidth && !isUniform)) {
                        scaleProp = prop;
                    }

                    if (pmName === "ADBE Rotate" || pmName === "ADBE Rotation" || pmName.indexOf("Rotate") !== -1 || pmName.indexOf("Rotation") !== -1 ||
                        pdName === "Rotation" || pdName === "Rotate" || pdName === "Drehung" || pdName === "Rotación" || pdName === "Rotazione" ||
                        pdName === "Обертання" || pdName === "回転" || pdName === "旋转") {
                        rotProp = prop;
                    }
                    if (pmName === "ADBE Anchor Point" || pmName.indexOf("Anchor") !== -1 ||
                        pdName === "Anchor Point" || pdName === "Point d'ancrage" || pdName === "Ankerpunkt" ||
                        pdName === "Punto de anclaje" || pdName === "Punto di ancoraggio" ||
                        pdName === "Точка прив'язки" ||
                        pdName === "アンカーポイント" || pdName === "锚点") {
                        anchorProp = prop;
                    }
                }

                // Гарантований fallback за стандартною структурою ADBE Motion в Premiere Pro:
                // props[0] = Position, props[1] = Scale, props[2] = Scale Width, props[3] = Uniform Scale
                if (!posProp && numProps >= 1) posProp = props[0];
                if (!scaleProp && numProps >= 2) scaleProp = props[1];
                if (!scaleWidthProp && numProps >= 3) scaleWidthProp = props[2];
                if (!uniformScaleProp && numProps >= 4) uniformScaleProp = props[3];

                // Захисна перевірка: scaleProp ніколи не повинен бути чекбоксом Uniform Scale або шириною Width
                if (scaleProp) {
                    var spm = "";
                    var spd = "";
                    try { if (scaleProp.matchName) spm = scaleProp.matchName; } catch (espm) {}
                    try { if (scaleProp.displayName) spd = scaleProp.displayName; } catch (espd) {}
                    if (spm.indexOf("Uniform") !== -1 || spd.indexOf("Uniform") !== -1 || spm.indexOf("Width") !== -1 || spd.indexOf("Width") !== -1) {
                        scaleProp = (numProps >= 2) ? props[1] : null;
                    }
                }

                if (!rotProp && numProps >= 5) {
                    for (var rp = 2; rp < numProps; rp++) {
                        var pCand = props[rp];
                        var pcn = "";
                        try { if (pCand.displayName) pcn = pCand.displayName; } catch (eCn) {}
                        if (pcn && (pcn.indexOf("Rot") !== -1 || pcn.indexOf("Оберт") !== -1)) {
                            rotProp = pCand;
                            break;
                        }
                    }
                }
            }
        } catch (eProps) {}
    }

    return { motionComp: motionComp, posProp: posProp, scaleProp: scaleProp, scaleWidthProp: scaleWidthProp, uniformScaleProp: uniformScaleProp, rotProp: rotProp, anchorProp: anchorProp };
}

// Версія цього скрипта. Панель порівнює її зі своєю версією й попереджає, якщо Premiere виконує застарілий скрипт
// (після OTA-оновлення, при застарілій копії розширення тощо). Синхронізується в tools/publish_update.js.
var AT_HOSTSCRIPT_VERSION = '1.1.7';
function getHostScriptVersion() {
    return AT_HOSTSCRIPT_VERSION;
}

// =====================================================================
// Резервні копії ключів Motion (кнопка «↶ Повернути як було»)
// Стек зберігається в $.__atKeyBackups і НЕ скидається при повторному $.evalFile цього файлу.
// =====================================================================
var _AT_BACKUP_MAX = 10;
try { if (typeof $ !== 'undefined' && !$.__atKeyBackups) { $.__atKeyBackups = []; } } catch (eBkInit) {}

function _atBackupStack() {
    try {
        if (!$.__atKeyBackups) $.__atKeyBackups = [];
        return $.__atKeyBackups;
    } catch (e) {
        return [];
    }
}

function _countPropKeys(prop) {
    try {
        if (prop && typeof prop.isTimeVarying === "function" && prop.isTimeVarying() && typeof prop.getKeys === "function") {
            var ks = prop.getKeys();
            return ks ? ks.length : 0;
        }
    } catch (e) {}
    return 0;
}

function _countMotionKeys(md) {
    var r = { pos: 0, scale: 0, rot: 0, total: 0 };
    if (!md) return r;
    r.pos   = _countPropKeys(md.posProp);
    r.scale = Math.max(_countPropKeys(md.scaleProp), _countPropKeys(md.scaleWidthProp));
    r.rot   = _countPropKeys(md.rotProp);
    r.total = r.pos + r.scale + r.rot;
    return r;
}

// Знімок властивості: статичне значення + усі ключі (ticks + значення)
function _snapshotProp(prop) {
    if (!prop) return null;
    var snap = { varying: false, value: null, keys: [] };
    try { snap.varying = (typeof prop.isTimeVarying === "function") && !!prop.isTimeVarying(); } catch (e) {}
    if (snap.varying && typeof prop.getKeys === "function") {
        try {
            var ks = prop.getKeys();
            var n = (typeof _getCollectionLength === 'function') ? _getCollectionLength(ks) : (ks ? (ks.length || (typeof ks.numItems === 'number' ? ks.numItems : 0)) : 0);
            for (var i = 0; i < n; i++) {
                var kt = ks[i];
                var v = null;
                try { v = prop.getValueAtKey(kt); } catch (eV) { continue; }
                var ticks = null;
                var secs = 0;
                try { if (kt && kt.ticks !== undefined) ticks = String(kt.ticks); } catch (eT) {}
                try {
                    if (typeof _getTimeSecondsSafe === 'function') {
                        secs = _getTimeSecondsSafe(kt);
                    } else if (kt && kt.seconds !== undefined) {
                        secs = kt.seconds;
                    }
                } catch (eS) {}
                snap.keys.push({ ticks: ticks, seconds: secs, value: v });
            }
        } catch (eK) {}
    }
    try { snap.value = prop.getValue(); } catch (eGv) {}
    return snap;
}

function _restorePropFromSnapshot(prop, snap) {
    if (!prop || !snap) return 0;
    var restored = 0;
    try {
        if (typeof prop.isTimeVarying === "function" && prop.isTimeVarying()) {
            prop.setTimeVarying(false);
        }
    } catch (eClr) {}

    if (snap.varying && snap.keys && snap.keys.length > 0) {
        try { prop.setTimeVarying(true); } catch (eTv) {}
        for (var i = 0; i < snap.keys.length; i++) {
            var k = snap.keys[i];
            var isLast = (i === snap.keys.length - 1);
            var ok = false;
            var t = null;
            try {
                t = new Time();
                if (k.ticks) { t.ticks = k.ticks; } else { t.seconds = k.seconds; }
            } catch (eT) { t = null; }
            if (t) {
                try { prop.addKey(t); prop.setValueAtKey(t, k.value, isLast); ok = true; } catch (eA) {}
            }
            if (!ok) {
                try { prop.addKey(k.seconds); prop.setValueAtKey(k.seconds, k.value, isLast); ok = true; } catch (eB) {}
            }
            if (ok) restored++;
        }
    } else if (snap.value !== null && snap.value !== undefined) {
        try { prop.setValue(snap.value, true); } catch (eSv) {
            try { prop.setValue(snap.value); } catch (eSv2) {}
        }
    }
    return restored;
}

// Виставляє Scale Width у задане значення (з updateUI і без) та перевіряє результат зчитуванням.
// Повертає true, якщо Premiere прийняв значення.
function _syncScaleWidthValue(scaleWidthProp, val) {
    if (!scaleWidthProp) return false;
    var attempts = [true, undefined];
    for (var ai = 0; ai < attempts.length; ai++) {
        try {
            if (attempts[ai] === true) scaleWidthProp.setValue(val, true);
            else scaleWidthProp.setValue(val);
        } catch (eSw) {}
        try {
            var cur = scaleWidthProp.getValue();
            if (cur && cur.length !== undefined && typeof cur !== "string") cur = cur[0];
            cur = parseFloat(cur);
            if (!isNaN(cur) && Math.abs(cur - val) < 0.5) return true;
        } catch (eRd) {}
    }
    return false;
}

// Відновлення Scale / Scale Width / Uniform Scale з резервної копії.
// ВАЖЛИВО: поки Uniform Scale увімкнено, Premiere блокує Scale Width (ключі й значення в ньому не змінюються).
// Тому спершу вимикаємо Uniform Scale, відновлюємо обидві властивості, і лише потім повертаємо збережений стан чекбокса.
function _restoreScaleProps(uniformProp, scaleProp, scaleWidthProp, b) {
    var restored = 0;
    if (!b) return 0;
    var hasUniform = !!uniformProp;
    var needWidth = !!(scaleWidthProp && b.scaleWidth);
    if (hasUniform && needWidth) {
        try { uniformProp.setValue(false, true); } catch (eU0) {
            try { uniformProp.setValue(false); } catch (eU1) {}
        }
    }
    if (scaleProp && b.scale) restored += _restorePropFromSnapshot(scaleProp, b.scale);
    if (needWidth) restored += _restorePropFromSnapshot(scaleWidthProp, b.scaleWidth);
    if (hasUniform && b.uniform !== null && b.uniform !== undefined) {
        try { uniformProp.setValue(b.uniform, true); } catch (eU2) {
            try { uniformProp.setValue(b.uniform); } catch (eU3) {}
        }
    }
    return restored;
}

function _findClipForBackup(seq, b) {
    if (!seq || !b) return null;
    var numTr = _getCollectionLength(seq.videoTracks);
    var ti, ci, trk, nCl, c;
    // 1. За nodeId
    if (b.nodeId) {
        for (ti = numTr - 1; ti >= 0; ti--) {
            try {
                trk = seq.videoTracks[ti];
                nCl = _getCollectionLength(trk.clips);
                for (ci = 0; ci < nCl; ci++) {
                    c = trk.clips[ci];
                    if (c && c.nodeId === b.nodeId) return c;
                }
            } catch (eN) {}
        }
    }
    // 2. За trackIndex/clipIndex + ім'я
    try {
        if (b.trackIndex >= 0 && b.trackIndex < numTr) {
            trk = seq.videoTracks[b.trackIndex];
            if (b.clipIndex >= 0 && b.clipIndex < _getCollectionLength(trk.clips)) {
                c = trk.clips[b.clipIndex];
                if (c && c.name === b.clipName) return c;
            }
        }
    } catch (eIdx) {}
    // 3. За ім'ям + початком на таймлайні
    for (ti = numTr - 1; ti >= 0; ti--) {
        try {
            trk = seq.videoTracks[ti];
            nCl = _getCollectionLength(trk.clips);
            for (ci = 0; ci < nCl; ci++) {
                c = trk.clips[ci];
                if (c && c.name === b.clipName && c.start &&
                    Math.abs(_getTimeSecondsSafe(c.start) - b.clipStart) < 0.05) {
                    return c;
                }
            }
        } catch (eNm) {}
    }
    return null;
}

/**
 * Повертає анімацію Motion останнього кліпу, на який плагін записував ключі,
 * до стану ДО запису. Знімає верхній запис зі стеку резервних копій.
 */
function restoreLastKeyframesBackup() {
    try {
        var stack = _atBackupStack();
        if (!stack || stack.length === 0) return _err("NO_BACKUP");
        if (!app || !app.project) return _err("NO_PROJECT");
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var b = stack[stack.length - 1];
        var clip = _findClipForBackup(seq, b);
        if (!clip) {
            stack.pop();
            return _err("BACKUP_CLIP_NOT_FOUND", b.clipName || "");
        }

        var md = _getMotionComponentAndProps(clip);
        if (!md.motionComp) {
            stack.pop();
            return _err("MOTION_COMPONENT_NOT_FOUND");
        }

        var restored = 0;
        restored += _restorePropFromSnapshot(md.posProp, b.pos);
        restored += _restoreScaleProps(md.uniformScaleProp, md.scaleProp, md.scaleWidthProp, b);
        restored += _restorePropFromSnapshot(md.rotProp, b.rot);

        stack.pop();
        try { $.gc(); } catch (eGc) {}

        return _v({
            success:      true,
            clipName:     b.clipName,
            trackIndex:   b.trackIndex,
            restoredKeys: restored,
            remaining:    stack.length
        });
    } catch (e) {
        return _err("EX_RESTORE", String(e));
    }
}

function getKeyframesBackupDepth() {
    return _v({ depth: _atBackupStack().length });
}

function isSameClip(c1, c2) {
    if (!c1 || !c2) return false;
    if (c1 === c2) return true;
    try {
        if (c1.nodeId && c2.nodeId && c1.nodeId === c2.nodeId) return true;
    } catch (e1) {}
    try {
        if (c1.name === c2.name && 
            c1.start && c2.start && Math.abs(_getTimeSecondsSafe(c1.start) - _getTimeSecondsSafe(c2.start)) < 0.001) {
            return true;
        }
    } catch (e2) {}
    return false;
}

function _getCollectionLength(col) {
    if (!col) return 0;
    try {
        if (col.numTracks !== undefined && col.numTracks !== null) {
            var nt = parseInt(col.numTracks, 10);
            if (!isNaN(nt) && nt >= 0) return nt;
        }
    } catch (e0) {}
    try {
        if (col.numItems !== undefined && col.numItems !== null) {
            var n = parseInt(col.numItems, 10);
            if (!isNaN(n) && n >= 0) return n;
        }
    } catch (e1) {}
    try {
        if (col.length !== undefined && col.length !== null) {
            var l = parseInt(col.length, 10);
            if (!isNaN(l) && l >= 0) return l;
        }
    } catch (e2) {}
    return 0;
}

function _isAudioClip(clip) {
    if (!clip) return false;
    try {
        if (clip.mediaType && String(clip.mediaType).toLowerCase() === "audio") return true;
    } catch (e) {}
    return false;
}

function _isTrackLockedSafe(trk) {
    if (!trk) return false;
    try {
        if (typeof trk.isLocked === "function") return Boolean(trk.isLocked());
    } catch (e) {}
    return false;
}

function _isTrackMutedSafe(trk) {
    if (!trk) return false;
    try {
        if (typeof trk.isMuted === "function") return Boolean(trk.isMuted());
    } catch (e) {}
    return false;
}

function _getTimeSecondsSafe(timeObj) {
    if (timeObj === null || timeObj === undefined) return 0;
    if (typeof timeObj === "number") return (isFinite(timeObj) && !isNaN(timeObj)) ? timeObj : 0;
    try {
        if (timeObj.seconds !== undefined && timeObj.seconds !== null) {
            var s = parseFloat(timeObj.seconds);
            if (!isNaN(s) && isFinite(s)) return s;
        }
    } catch (e1) {}
    try {
        if (timeObj.ticks !== undefined && timeObj.ticks !== null) {
            var t = parseFloat(timeObj.ticks);
            if (!isNaN(t) && isFinite(t)) return t / 254016000000;
        }
    } catch (e2) {}
    return 0;
}

function _getPlayheadSecondsSafe(seq) {
    if (!seq) return 0;
    try {
        if (seq.getPlayerPosition) {
            var pPos = seq.getPlayerPosition();
            if (pPos !== null && pPos !== undefined) {
                return _getTimeSecondsSafe(pPos);
            }
        }
    } catch (e1) {}
    try {
        if (seq.CTI) {
            return _getTimeSecondsSafe(seq.CTI);
        }
    } catch (e2) {}
    return 0;
}

function getSelectedClipInfo() {
    try {
        if (!app || !app.project) return _err("NO_PROJECT");
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var clip = null;
        var audioFallbackClip = null;
        var selection = null;
        try { selection = seq.getSelection(); } catch (e) { selection = null; }

        var selLen = _getCollectionLength(selection);
        if (selection && selLen > 0) {
            for (var sIdx = 0; sIdx < selLen; sIdx++) {
                try {
                    var candClip = selection[sIdx];
                    if (candClip) {
                        if (!_isAudioClip(candClip)) {
                            clip = candClip;
                            break;
                        } else if (!audioFallbackClip) {
                            audioFallbackClip = candClip;
                        }
                    }
                } catch (eSelIt) {}
            }
        }

        var playSec = _getPlayheadSecondsSafe(seq);
        if (!clip && audioFallbackClip && audioFallbackClip.start) {
            playSec = _getTimeSecondsSafe(audioFallbackClip.start);
        }

        // Fallback 1: Clip under playhead (if timeline lost focus when clicking CEP panel on macOS)
        if (!clip) {
            try {
                var numTr = _getCollectionLength(seq.videoTracks);
                for (var pass = 0; pass < 2 && !clip; pass++) {
                    for (var t = numTr - 1; t >= 0; t--) {
                        try {
                            var trk = seq.videoTracks[t];
                            if (!trk) continue;
                            if (pass === 0 && _isTrackMutedSafe(trk)) continue;
                            var numClips = _getCollectionLength(trk.clips);
                            for (var c = 0; c < numClips; c++) {
                                try {
                                    var candidate = trk.clips[c];
                                    if (candidate && candidate.start && candidate.end) {
                                        var cStart = _getTimeSecondsSafe(candidate.start);
                                        var cEnd   = _getTimeSecondsSafe(candidate.end);
                                        if (playSec >= (cStart - 0.02) && playSec <= (cEnd + 0.02)) {
                                            clip = candidate;
                                            break;
                                        }
                                    }
                                } catch (eCand) {}
                            }
                        } catch (eTrk) {}
                        if (clip) break;
                    }
                }
            } catch (e1) {}
        }

        // Fallback 2: Nearest or first clip across ALL video tracks (V1..Vn)
        if (!clip) {
            try {
                var numTrAll = _getCollectionLength(seq.videoTracks);
                var bestClip = null;
                var bestDist = 1e12;
                for (var tAll = 0; tAll < numTrAll; tAll++) {
                    try {
                        var trkAll = seq.videoTracks[tAll];
                        if (!trkAll) continue;
                        var nClipsAll = _getCollectionLength(trkAll.clips);
                        for (var cAll = 0; cAll < nClipsAll; cAll++) {
                            try {
                                var candAll = trkAll.clips[cAll];
                                if (!candAll) continue;
                                if (!bestClip) bestClip = candAll;
                                if (candAll.start && candAll.end) {
                                    var cs = _getTimeSecondsSafe(candAll.start);
                                    var ce = _getTimeSecondsSafe(candAll.end);
                                    var dist = (playSec < cs) ? (cs - playSec) : ((playSec > ce) ? (playSec - ce) : 0);
                                    if (dist < bestDist) {
                                        bestDist = dist;
                                        bestClip = candAll;
                                    }
                                }
                            } catch (eCAll) {}
                        }
                    } catch (eTAll) {}
                }
                if (bestClip) clip = bestClip;
            } catch (e2) {}
        }

        if (!clip && audioFallbackClip) {
            clip = audioFallbackClip;
        }

        if (!clip) return _err("NO_CLIP_FOUND");

        var clipName = "Clip";
        try { if (clip.name) clipName = clip.name; } catch (e) {}

        var filePath = "";
        try {
            if (clip.projectItem && clip.projectItem.getMediaPath) {
                filePath = clip.projectItem.getMediaPath() || "";
            }
        } catch (e) { filePath = ""; }

        if (!filePath) {
            try { if (clip.mediaPath) filePath = clip.mediaPath || ""; } catch (e) {}
        }

        // Fallback: search in project bins by clip name
        if (!filePath && clipName) {
            try {
                function _findItemMedia(bin, targetName) {
                    if (!bin) return "";
                    var cnt = 0;
                    try { cnt = bin.children.numItems; } catch(e) { return ""; }
                    for (var bi = 0; bi < cnt; bi++) {
                        var it = bin.children[bi];
                        if (it && it.name === targetName) {
                            var p = "";
                            try { if (it.getMediaPath) p = it.getMediaPath() || ""; } catch(e) {}
                            if (!p) { try { if (it.mediaPath) p = it.mediaPath || ""; } catch(e) {} }
                            if (p) return p;
                        }
                        if (it && it.children && it.children.numItems > 0) {
                            var subP = _findItemMedia(it, targetName);
                            if (subP) return subP;
                        }
                    }
                    return "";
                }
                filePath = _findItemMedia(app.project.rootItem, clipName);
            } catch (e3) {}
        }

        var fps = 25;
        var width = 1920;
        var height = 1080;
        try {
            var settings = seq.getSettings();
            if (settings && settings.videoFrameRate && settings.videoFrameRate.ticks) {
                var ticksNum = parseFloat(settings.videoFrameRate.ticks);
                if (ticksNum > 0) {
                    fps = 254016000000 / ticksNum;
                }
            }
            if (isNaN(fps) || !isFinite(fps) || fps <= 0) fps = 25;
            if (settings && settings.videoFrameWidth) width = settings.videoFrameWidth;
            if (settings && settings.videoFrameHeight) height = settings.videoFrameHeight;
        } catch (eSettings) { fps = 25; }

        filePath = _cleanMediaPath(filePath);

        var dur = 10;
        try {
            if (clip.end && clip.start) dur = Math.max(0.1, _getTimeSecondsSafe(clip.end) - _getTimeSecondsSafe(clip.start));
        } catch (eDur) {}

        var inSec = 0;
        var outSec = inSec + dur;
        var startSec = 0;
        var endSec = dur;
        try { if (clip.inPoint) inSec = _getTimeSecondsSafe(clip.inPoint); } catch (e) {}
        try { if (clip.outPoint) outSec = _getTimeSecondsSafe(clip.outPoint); } catch (e) { outSec = inSec + dur; }
        if (outSec <= inSec) outSec = inSec + dur;
        try { if (clip.start) startSec = _getTimeSecondsSafe(clip.start); } catch (e) {}
        try { if (clip.end) endSec = _getTimeSecondsSafe(clip.end); } catch (e) { endSec = startSec + dur; }

        var playheadSec = _getPlayheadSecondsSafe(seq);

        var clipSpeed = 1.0;
        var hasTimeRemapping = false;
        try {
            if (clip.getSpeed) clipSpeed = clip.getSpeed();
        } catch (eSpd) {}
        var speedMul = (clipSpeed && isFinite(clipSpeed) && clipSpeed > 0) ? (clipSpeed > 20 ? (clipSpeed / 100.0) : clipSpeed) : 1.0;

        var clipPlayheadSec = inSec + Math.max(0, Math.min(outSec - inSec, (playheadSec - startSec) * speedMul));

        var trackIndex = 0;
        var clipIndex = 0;
        var found = false;
        try {
            var tracks = seq.videoTracks;
            var numVTracks = _getCollectionLength(tracks);
            for (var i = 0; i < numVTracks; i++) {
                try {
                    var track = tracks[i];
                    var numVClips = _getCollectionLength(track.clips);
                    for (var j = 0; j < numVClips; j++) {
                        if (isSameClip(track.clips[j], clip)) {
                            trackIndex = i;
                            clipIndex = j;
                            found = true;
                            break;
                        }
                    }
                } catch (eTrIdx) {}
                if (found) break;
            }
        } catch (e) {}

        var clipNodeId = "";
        try { if (clip.nodeId) clipNodeId = clip.nodeId; } catch (eNode) {}

        try {
            if (clip.components) {
                var numCmp = _getCollectionLength(clip.components);
                for (var ci = 0; ci < numCmp; ci++) {
                    var cmp = clip.components[ci];
                    if (cmp && (cmp.displayName === "Time Remapping" || cmp.matchName === "AE.ADBE Time Remapping")) {
                        hasTimeRemapping = true;
                        break;
                    }
                }
            }
        } catch (eTr) {}

        var srcExistingKeys = null;
        try { srcExistingKeys = _countMotionKeys(_getMotionComponentAndProps(clip)); } catch (eSrcKeys) {}

        return _v({
            name:            clipName,
            nodeId:          clipNodeId,
            existingKeys:    srcExistingKeys,
            filePath:        filePath,
            inPoint:         inSec,
            outPoint:        outSec,
            startOnTimeline: startSec,
            endOnTimeline:   endSec,
            playheadSeconds: playheadSec,
            sourceFrameTime: clipPlayheadSec,
            trackIndex:      trackIndex,
            clipIndex:       clipIndex,
            fps:             fps,
            width:           width,
            height:          height,
            sequenceWidth:   width,
            sequenceHeight:  height,
            speed:           clipSpeed,
            hasTimeRemapping: hasTimeRemapping
        });

    } catch (e) {
        return _err("EX_GET_CLIP", String(e));
    }
}

function getPlayheadTime(clipNodeId) {
    try {
        if (!app || !app.project) return _err("NO_PROJECT");
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var playheadSec = _getPlayheadSecondsSafe(seq);

        var clip = null;

        // 1. Швидка перевірка поточного виділення (O(1))
        try {
            var sel = seq.getSelection();
            var selLen = _getCollectionLength(sel);
            if (sel && selLen > 0) {
                for (var si0 = 0; si0 < selLen; si0++) {
                    var sc0 = sel[si0];
                    if (sc0 && !_isAudioClip(sc0)) {
                        if (!clipNodeId || (sc0.nodeId && sc0.nodeId === clipNodeId)) {
                            clip = sc0;
                            break;
                        }
                    }
                }
            }
        } catch (eSelFast) {}

        // 2. Пошук за clipNodeId, якщо виділений кліп інший
        if (!clip && clipNodeId) {
            try {
                var numTrk = _getCollectionLength(seq.videoTracks);
                for (var t1 = 0; t1 < numTrk; t1++) {
                    try {
                        var trk1 = seq.videoTracks[t1];
                        var numCl1 = _getCollectionLength(trk1.clips);
                        for (var c1 = 0; c1 < numCl1; c1++) {
                            var candidate1 = trk1.clips[c1];
                            if (candidate1 && candidate1.nodeId && candidate1.nodeId === clipNodeId) {
                                clip = candidate1;
                                break;
                            }
                        }
                    } catch (eTr1) {}
                    if (clip) break;
                }
            } catch (eNId) {}
        }

        // 3. Fallback: поточне виділення на таймлайні
        if (!clip) {
            try {
                var sel2 = seq.getSelection();
                var sel2Len = _getCollectionLength(sel2);
                if (sel2 && sel2Len > 0) {
                    for (var si2 = 0; si2 < sel2Len; si2++) {
                        if (sel2[si2] && !_isAudioClip(sel2[si2])) {
                            clip = sel2[si2];
                            break;
                        }
                    }
                    if (!clip) clip = sel2[0];
                }
            } catch (eSel) {}
        }

        // 4. Fallback: clip under playhead
        if (!clip) {
            try {
                var numTr = _getCollectionLength(seq.videoTracks);
                for (var t = numTr - 1; t >= 0; t--) {
                    try {
                        var trk = seq.videoTracks[t];
                        var numCl = _getCollectionLength(trk.clips);
                        for (var c = 0; c < numCl; c++) {
                            var cand = trk.clips[c];
                            if (cand && cand.start && cand.end) {
                                var cs = _getTimeSecondsSafe(cand.start);
                                var ce = _getTimeSecondsSafe(cand.end);
                                if (playheadSec >= (cs - 0.02) && playheadSec <= (ce + 0.02)) {
                                    clip = cand;
                                    break;
                                }
                            }
                        }
                    } catch (eTrP) {}
                    if (clip) break;
                }
            } catch (eClip) {}
        }

        var sourceFrameTime = playheadSec;
        var clipFound = false;
        var inSec = 0;
        var outSec = 10;
        var startSec = 0;
        if (clip) {
            clipFound = true;
            try { if (clip.inPoint) inSec = _getTimeSecondsSafe(clip.inPoint); } catch (eIn) {}
            try { if (clip.outPoint) outSec = _getTimeSecondsSafe(clip.outPoint); } catch (eOut) {}
            try { if (clip.start) startSec = _getTimeSecondsSafe(clip.start); } catch (eSt) {}
            var phClipSpeed = 1.0;
            try { if (clip.getSpeed) phClipSpeed = clip.getSpeed(); } catch (ePhSpd) {}
            var phSpeedMul = (phClipSpeed && isFinite(phClipSpeed) && phClipSpeed > 0) ? (phClipSpeed > 20 ? (phClipSpeed / 100.0) : phClipSpeed) : 1.0;
            sourceFrameTime = inSec + Math.max(0, Math.min(outSec - inSec, (playheadSec - startSec) * phSpeedMul));
        }

        return _v({
            playheadSeconds: playheadSec,
            sourceFrameTime: sourceFrameTime,
            clipFound:       clipFound,
            inPoint:         inSec,
            outPoint:        outSec,
            startOnTimeline: startSec
        });
    } catch (e) {
        return _err("EX_GET_PLAYHEAD", String(e));
    }
}

function setPlayheadTime(seconds) {
    try {
        if (!app || !app.project) return _err("NO_PROJECT");
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var sec = parseFloat(seconds);
        if (!_isNum(sec)) return _err("INVALID_SECONDS", String(seconds));
        var tickRate = 254016000000;
        var ticks = String(Math.round(sec * tickRate));
        if (seq.setPlayerPosition) {
            seq.setPlayerPosition(ticks);
            return _v({ success: true, seconds: sec, ticks: ticks });
        }
        return _err("SET_PLAYER_POS_UNAVAILABLE");
    } catch (e) {
        return _err("EX_SET_PLAYHEAD", String(e));
    }
}

function getSelectedLayerInfo() {
    try {
        if (!app || !app.project) return _err("NO_PROJECT");
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var clip = null;
        var selection = null;
        try { selection = seq.getSelection(); } catch (e) { selection = null; }

        var selLen = _getCollectionLength(selection);
        if (selection && selLen > 0) {
            var videoSelection = [];
            for (var si = 0; si < selLen; si++) {
                try {
                    if (selection[si] && !_isAudioClip(selection[si])) {
                        videoSelection.push(selection[si]);
                    }
                } catch (eSi) {}
            }
            if (videoSelection.length >= 2) {
                clip = videoSelection[1];
            } else if (videoSelection.length === 1) {
                clip = videoSelection[0];
            }
        }

        // Fallback: Check top tracks under playhead
        if (!clip) {
            try {
                var playSec = _getPlayheadSecondsSafe(seq);
                var numTr = _getCollectionLength(seq.videoTracks);
                var minTrackIdx = (numTr > 1) ? 1 : 0;
                for (var t = numTr - 1; t >= minTrackIdx; t--) {
                    try {
                        var trk = seq.videoTracks[t];
                        if (!trk) continue;
                        if (_isTrackLockedSafe(trk)) continue;
                        if (_isTrackMutedSafe(trk)) continue;
                        var numCl = _getCollectionLength(trk.clips);
                        for (var c = 0; c < numCl; c++) {
                            try {
                                var candidate = trk.clips[c];
                                if (candidate && candidate.start && candidate.end) {
                                    var cStart = _getTimeSecondsSafe(candidate.start);
                                    var cEnd   = _getTimeSecondsSafe(candidate.end);
                                    if (playSec >= (cStart - 0.02) && playSec <= (cEnd + 0.02)) {
                                        clip = candidate;
                                        break;
                                    }
                                }
                            } catch (eCandL) {}
                        }
                    } catch (eTrkL) {}
                    if (clip) break;
                }
            } catch (e1) {}
        }

        if (!clip) return _err("NO_TARGET_LAYER_FOUND");

        var clipName = "Target Layer";
        try { if (clip.name) clipName = clip.name; } catch (e) {}

        var startSec = 0;
        var endSec = 0;
        var inSec = 0;
        var outSec = 0;
        try { if (clip.start) startSec = _getTimeSecondsSafe(clip.start); } catch (e) {}
        try { if (clip.end) endSec = _getTimeSecondsSafe(clip.end); } catch (e) {}
        try { if (clip.inPoint) inSec = _getTimeSecondsSafe(clip.inPoint); } catch (e) {}
        try { if (clip.outPoint) outSec = _getTimeSecondsSafe(clip.outPoint); } catch (e) {}

        var trackIndex = 0;
        var clipIndex = 0;
        var found = false;
        try {
            var tracks = seq.videoTracks;
            var nTr = _getCollectionLength(tracks);
            for (var i = nTr - 1; i >= 0; i--) {
                try {
                    var track = tracks[i];
                    var nCl = _getCollectionLength(track.clips);
                    for (var j = 0; j < nCl; j++) {
                        if (isSameClip(track.clips[j], clip)) {
                            trackIndex = i;
                            clipIndex = j;
                            found = true;
                            break;
                        }
                    }
                } catch (eTrL2) {}
                if (found) break;
            }
        } catch (e) {}

        var clipNodeId = "";
        try { if (clip.nodeId) clipNodeId = clip.nodeId; } catch (eNode2) {}

        var isStill = false;
        try {
            var pi = clip.projectItem;
            if (pi && pi.name && pi.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
                isStill = true;
            }
        } catch (eStill) {}
        if (!isStill && clip.name && clip.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
            isStill = true;
        }

        var curPos = null;
        var curScale = null;
        var layerMotion = _getMotionComponentAndProps(clip);
        if (layerMotion.posProp) {
            try { curPos = layerMotion.posProp.getValue(); } catch (ePosG) {}
        }
        if (layerMotion.scaleProp) {
            try { curScale = layerMotion.scaleProp.getValue(); } catch (eScG) {}
        }

        return _v({
            name:            clipName,
            nodeId:          clipNodeId,
            trackIndex:      trackIndex,
            clipIndex:       clipIndex,
            startOnTimeline: startSec,
            endOnTimeline:   endSec,
            inPoint:         inSec,
            outPoint:        outSec,
            isStill:         isStill,
            curPos:          curPos,
            curScale:        curScale,
            existingKeys:    _countMotionKeys(layerMotion)
        });

    } catch (e) {
        return _err("EX_GET_LAYER", String(e));
    }
}

function applyKeyframesToClip(paramsJson) {
    try {
        if (typeof paramsJson === "string") {
            try {
                if (paramsJson.indexOf("%") !== -1) {
                    paramsJson = decodeURIComponent(paramsJson);
                }
            } catch (eDec) {}
        }
        var params = _parse(paramsJson);
        if (!params) return _err("INVALID_JSON_PARAMS");

        if (!app || !app.project) return _err("NO_PROJECT");
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var trackIndex   = params.trackIndex;
        var clipIndex    = params.clipIndex;
        var keyframes    = params.keyframes;
        var doPos        = (params.trackPosition !== false);
        var doScale      = (params.trackScale !== false);
        var doRot        = (params.trackRotation === true);
        var applyMode    = params.applyMode || 'attach';
        var targetNodeId = params.nodeId;
        var targetName   = params.clipName;

        if (!keyframes || keyframes.length === 0) return _err("NO_KEYFRAMES");

        var clip = null;
        var numSeqTracks = _getCollectionLength(seq.videoTracks);

        // 0. Пріоритет 0: Швидка перевірка за відомими trackIndex та clipIndex (O(1))
        if (trackIndex !== undefined && trackIndex >= 0 && trackIndex < numSeqTracks) {
            try {
                var directTrack = seq.videoTracks[trackIndex];
                if (directTrack && !_isTrackLockedSafe(directTrack)) {
                    var numDirectClips = _getCollectionLength(directTrack.clips);
                    if (clipIndex !== undefined && clipIndex >= 0 && clipIndex < numDirectClips) {
                        var directClip = directTrack.clips[clipIndex];
                        if (directClip) {
                            if ((targetNodeId && directClip.nodeId === targetNodeId) ||
                                (targetName && directClip.name === targetName)) {
                                clip = directClip;
                            }
                        }
                    }
                }
            } catch (eDirect) {}
        }

        // 1. Пріоритет 1: поточне виділення на таймлайні
        if (!clip) {
            try {
                var sel = seq.getSelection();
                var selCount = _getCollectionLength(sel);
                if (sel && selCount > 0) {
                    for (var si = 0; si < selCount; si++) {
                        var sc = sel[si];
                        if (!sc || _isAudioClip(sc)) continue;
                        if (targetNodeId && sc.nodeId && sc.nodeId === targetNodeId) {
                            clip = sc;
                            break;
                        }
                        if (targetName && sc.name && sc.name === targetName) {
                            clip = sc;
                            break;
                        }
                    }
                }
            } catch (eSel) {}
        }

        // 1. Пошук по nodeId зверху вниз (від вищих треків до нижчих)
        if (!clip && targetNodeId) {
            try {
                for (var ti = numSeqTracks - 1; ti >= 0; ti--) {
                    try {
                        var trk = seq.videoTracks[ti];
                        if (!trk || _isTrackLockedSafe(trk)) continue;
                        var nClTi = _getCollectionLength(trk.clips);
                        for (var ci = 0; ci < nClTi; ci++) {
                            if (trk.clips[ci] && trk.clips[ci].nodeId === targetNodeId) {
                                clip = trk.clips[ci];
                                trackIndex = ti;
                                clipIndex = ci;
                                break;
                            }
                        }
                    } catch (eTi) {}
                    if (clip) break;
                }
            } catch (eNode) {}
        }

        // 2. Пошук по назві кліпу (з верифікацією clipStartOnTimeline, якщо задано)
        if (!clip && targetName) {
            try {
                for (var tiN = numSeqTracks - 1; tiN >= 0; tiN--) {
                    try {
                        var trkN = seq.videoTracks[tiN];
                        if (!trkN || _isTrackLockedSafe(trkN)) continue;
                        var nClTiN = _getCollectionLength(trkN.clips);
                        for (var ciN = 0; ciN < nClTiN; ciN++) {
                            var candN = trkN.clips[ciN];
                            if (candN && candN.name === targetName) {
                                if (params.clipStartOnTimeline !== undefined && candN.start) {
                                    if (Math.abs(_getTimeSecondsSafe(candN.start) - params.clipStartOnTimeline) > 0.05) {
                                        continue;
                                    }
                                }
                                clip = candN;
                                trackIndex = tiN;
                                clipIndex = ciN;
                                break;
                            }
                        }
                    } catch (eTiN) {}
                    if (clip) break;
                }
            } catch (eName) {}
        }

        // 3. Fallback: по заданому trackIndex та clipIndex
        if (!clip) {
            try {
                if (trackIndex >= 0 && trackIndex < numSeqTracks) {
                    var tTrack = seq.videoTracks[trackIndex];
                    if (tTrack && !_isTrackLockedSafe(tTrack)) {
                        var nClT = _getCollectionLength(tTrack.clips);
                        if (clipIndex >= 0 && clipIndex < nClT) {
                            clip = tTrack.clips[clipIndex];
                        }
                    }
                }
            } catch (eFb3) {}
        }

        // 4. Fallback: пошук по startOnTimeline зверху вниз (від найвищого треку до 0)
        if (!clip && params.clipStartOnTimeline !== undefined) {
            try {
                for (var ti2 = numSeqTracks - 1; ti2 >= 0; ti2--) {
                    try {
                        var trk2 = seq.videoTracks[ti2];
                        if (!trk2 || _isTrackLockedSafe(trk2)) continue;
                        var nCl2 = _getCollectionLength(trk2.clips);
                        for (var ci2 = 0; ci2 < nCl2; ci2++) {
                            var cand = trk2.clips[ci2];
                            if (cand && cand.start && Math.abs(_getTimeSecondsSafe(cand.start) - params.clipStartOnTimeline) < 0.05) {
                                clip = cand;
                                trackIndex = ti2;
                                clipIndex = ci2;
                                break;
                            }
                        }
                    } catch (eTi2) {}
                    if (clip) break;
                }
            } catch (eCand) {}
        }

        if (!clip) return _err("CLIP_NOT_FOUND");

        // Оновлюємо фактичний trackIndex для звіту (лише якщо ще не визначено)
        if (trackIndex < 0) {
            try {
                var foundTrackIdx = false;
                for (var fti = numSeqTracks - 1; fti >= 0; fti--) {
                    var ftrk = seq.videoTracks[fti];
                    var nFCl = _getCollectionLength(ftrk.clips);
                    for (var fci = 0; fci < nFCl; fci++) {
                        if (isSameClip(ftrk.clips[fci], clip)) {
                            trackIndex = fti;
                            clipIndex = fci;
                            foundTrackIdx = true;
                            break;
                        }
                    }
                    if (foundTrackIdx) break;
                }
            } catch (eFti) {}
        }

        // Перевірка на статичне зображення (png, jpg тощо)
        var isStill = false;
        try {
            var pi = clip.projectItem;
            if (pi && pi.name && pi.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
                isStill = true;
            }
        } catch (eStill) {}
        if (!isStill && clip.name && clip.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
            isStill = true;
        }

        var motionData = _getMotionComponentAndProps(clip);
        var motionComp = motionData.motionComp;
        var posProp    = motionData.posProp;
        var scaleProp  = motionData.scaleProp;
        var scaleWidthProp = motionData.scaleWidthProp;
        var uniformScaleProp = motionData.uniformScaleProp;
        var rotProp    = motionData.rotProp;
        var anchorProp = motionData.anchorProp;

        if (!motionComp) return _err("MOTION_COMPONENT_NOT_FOUND");

        var seqW = 1920;
        var seqH = 1080;
        try {
            var st = seq.getSettings();
            if (st && st.videoFrameWidth) seqW = st.videoFrameWidth;
            if (st && st.videoFrameHeight) seqH = st.videoFrameHeight;
        } catch (eSeq) {}

        var srcW = (params.sourceWidth && params.sourceWidth > 0) ? params.sourceWidth : seqW;
        var srcH = (params.sourceHeight && params.sourceHeight > 0) ? params.sourceHeight : seqH;
        var scaleRatioX = seqW / srcW;
        var scaleRatioY = seqH / srcH;

        var initLayerX = Math.round(seqW / 2);
        var initLayerY = Math.round(seqH / 2);
        var initLayerScale = 100;
        var initLayerScaleX = 100;
        var initLayerScaleY = 100;
        var initLayerRot = 0;
        var initAnchorX = srcW / 2;
        var initAnchorY = srcH / 2;
        var originalIsNormalized = true;

        // Зчитуємо початкові значення властивостей (якщо шар вже мав ключі з попереднього запуску — беремо значення першого ключа)
        if (posProp) {
            try {
                var curPosVal = null;
                try {
                    if (typeof posProp.isTimeVarying === "function" && posProp.isTimeVarying() && typeof posProp.getKeys === "function") {
                        var oldPosKeys = posProp.getKeys();
                        if (oldPosKeys && oldPosKeys.length > 0) {
                            curPosVal = posProp.getValueAtKey(oldPosKeys[0]);
                        }
                    }
                } catch (eOldPK) {}
                if (curPosVal === null || curPosVal === undefined) {
                    curPosVal = posProp.getValue();
                }
                if (typeof curPosVal === "string") {
                    try {
                        var cleaned = curPosVal.replace(/[\[\]\(\)\s]/g, "");
                        var parts = cleaned.split(",");
                        if (parts.length >= 2) {
                            curPosVal = [parseFloat(parts[0]), parseFloat(parts[1])];
                        } else {
                            curPosVal = eval('(' + curPosVal + ')');
                        }
                    } catch (eEval) {}
                }
                if (curPosVal && curPosVal.length >= 2) {
                    var rx = parseFloat(curPosVal[0]);
                    var ry = parseFloat(curPosVal[1]);
                    if (!isNaN(rx) && !isNaN(ry)) {
                        if (rx >= 0 && rx <= 1.05 && ry >= 0 && ry <= 1.05 && seqW > 100) {
                            originalIsNormalized = true;
                            initLayerX = Math.round(rx * seqW);
                            initLayerY = Math.round(ry * seqH);
                        } else {
                            originalIsNormalized = false;
                            initLayerX = rx;
                            initLayerY = ry;
                        }
                    }
                }
            } catch (ePosVal) {}
        }

        if (anchorProp) {
            try {
                var curAncVal = anchorProp.getValue();
                if (typeof curAncVal === "string") {
                    try {
                        var cleanedA = curAncVal.replace(/[\[\]\(\)\s]/g, "");
                        var partsA = cleanedA.split(",");
                        if (partsA.length >= 2) {
                            curAncVal = [parseFloat(partsA[0]), parseFloat(partsA[1])];
                        } else {
                            curAncVal = eval('(' + curAncVal + ')');
                        }
                    } catch (eAncEval) {}
                }
                if (curAncVal && curAncVal.length >= 2) {
                    var ax = parseFloat(curAncVal[0]);
                    var ay = parseFloat(curAncVal[1]);
                    if (!isNaN(ax) && !isNaN(ay)) {
                        if (ax >= 0 && ax <= 1.05 && ay >= 0 && ay <= 1.05 && srcW > 100) {
                            initAnchorX = ax * srcW;
                            initAnchorY = ay * srcH;
                        } else {
                            initAnchorX = ax;
                            initAnchorY = ay;
                        }
                    }
                }
            } catch (eAnc) {}
        }

        if (scaleProp) {
            try {
                var curScVal = null;
                try {
                    if (typeof scaleProp.isTimeVarying === "function" && scaleProp.isTimeVarying() && typeof scaleProp.getKeys === "function") {
                        var oldScKeys = scaleProp.getKeys();
                        if (oldScKeys && oldScKeys.length > 0) {
                            curScVal = scaleProp.getValueAtKey(oldScKeys[0]);
                        }
                    }
                } catch (eOldSK) {}
                if (curScVal === null || curScVal === undefined) {
                    curScVal = scaleProp.getValue();
                }
                if (typeof curScVal === "string") {
                    try {
                        var parsedSc = eval('(' + curScVal + ')');
                        if (parsedSc && parsedSc.length !== undefined && parsedSc.length > 0) {
                            curScVal = parseFloat(parsedSc[0]);
                        } else {
                            curScVal = parseFloat(curScVal);
                        }
                    } catch (eScP) {
                        curScVal = parseFloat(curScVal.replace(/[^0-9.-]/g, ''));
                    }
                } else if (curScVal && curScVal.length !== undefined && curScVal.length > 0) {
                    curScVal = parseFloat(curScVal[0]);
                }
                if (typeof curScVal === "number" && !isNaN(curScVal) && curScVal > 0) {
                    initLayerScale = curScVal;
                    initLayerScaleY = curScVal;
                    initLayerScaleX = curScVal;
                }
            } catch (e3) {}
        }

        // Поки Uniform Scale увімкнено, Premiere використовує лише Scale (висоту); окремий Scale Width тоді може лишатися
        // застарілим (наприклад 100% при реальних 37%). Якщо взяти його як початковий масштаб ширини, шар розтягується по ширині.
        var uniformOnAtStart = true;
        if (uniformScaleProp) {
            try {
                var uv0 = uniformScaleProp.getValue();
                if (uv0 === false || uv0 === 0 || uv0 === "false" || uv0 === "0") uniformOnAtStart = false;
            } catch (eUv0) {}
        }

        if (scaleWidthProp && !uniformOnAtStart) {
            try {
                var curScWVal = null;
                try {
                    if (typeof scaleWidthProp.isTimeVarying === "function" && scaleWidthProp.isTimeVarying() && typeof scaleWidthProp.getKeys === "function") {
                        var oldScWKeys = scaleWidthProp.getKeys();
                        if (oldScWKeys && oldScWKeys.length > 0) {
                            curScWVal = scaleWidthProp.getValueAtKey(oldScWKeys[0]);
                        }
                    }
                } catch (eOldSKW) {}
                if (curScWVal === null || curScWVal === undefined) {
                    curScWVal = scaleWidthProp.getValue();
                }
                if (typeof curScWVal === "string") {
                    try {
                        var parsedScW = eval('(' + curScWVal + ')');
                        if (parsedScW && parsedScW.length !== undefined && parsedScW.length > 0) {
                            curScWVal = parseFloat(parsedScW[0]);
                        } else {
                            curScWVal = parseFloat(curScWVal);
                        }
                    } catch (eScWP) {
                        curScWVal = parseFloat(curScWVal.replace(/[^0-9.-]/g, ''));
                    }
                } else if (curScWVal && curScWVal.length !== undefined && curScWVal.length > 0) {
                    curScWVal = parseFloat(curScWVal[0]);
                }
                if (typeof curScWVal === "number" && !isNaN(curScWVal) && curScWVal > 0) {
                    initLayerScaleX = curScWVal;
                }
            } catch (eScWRead) {}
        }
        if (uniformOnAtStart) {
            initLayerScaleX = initLayerScale;
        }

        if (rotProp) {
            try {
                var curRotVal = null;
                try {
                    if (typeof rotProp.isTimeVarying === "function" && rotProp.isTimeVarying() && typeof rotProp.getKeys === "function") {
                        var oldRotKeys = rotProp.getKeys();
                        if (oldRotKeys && oldRotKeys.length > 0) {
                            curRotVal = rotProp.getValueAtKey(oldRotKeys[0]);
                        }
                    }
                } catch (eOldRK) {}
                if (curRotVal === null || curRotVal === undefined) {
                    curRotVal = rotProp.getValue();
                }
                if (typeof curRotVal === "string") {
                    try {
                        var parsedRot = eval('(' + curRotVal + ')');
                        if (parsedRot && parsedRot.length !== undefined && parsedRot.length > 0) {
                            curRotVal = parseFloat(parsedRot[0]);
                        } else {
                            curRotVal = parseFloat(curRotVal);
                        }
                    } catch (eRP) {
                        curRotVal = parseFloat(curRotVal.replace(/[^0-9.-]/g, ''));
                    }
                } else if (curRotVal && curRotVal.length !== undefined && curRotVal.length > 0) {
                    curRotVal = parseFloat(curRotVal[0]);
                }
                if (typeof curRotVal === "number" && !isNaN(curRotVal)) {
                    initLayerRot = curRotVal;
                }
            } catch (eRot) {}
        }

        // Резервна копія існуючої анімації ПЕРЕД очищенням — для кнопки «↶ Повернути як було».
        // Знімаємо лише ті властивості, які цей запис реально змінить.
        var skipBackup = (params.skipBackup === true);
        var backupStack = _atBackupStack();
        var backupEntryPushed = false;
        var backupKeysCount = 0;
        var backupEntry = null;

        if (!skipBackup) {
            var isReapplyOrRetrack = (params.isReapply === true || params.isRetrack === true);
            var topEntry = (backupStack && backupStack.length > 0) ? backupStack[backupStack.length - 1] : null;
            var isSameClipAsTop = false;
            if (topEntry) {
                try {
                    if (clip.nodeId && topEntry.nodeId && clip.nodeId === topEntry.nodeId) {
                        isSameClipAsTop = true;
                    } else if (topEntry.trackIndex === trackIndex && topEntry.clipIndex === clipIndex) {
                        var cSt = clip.start ? _getTimeSecondsSafe(clip.start) : 0;
                        if (Math.abs(topEntry.clipStart - cSt) < 0.05) {
                            isSameClipAsTop = true;
                        }
                    }
                } catch (eSame) {}
            }

            if (isReapplyOrRetrack && isSameClipAsTop) {
                // Вже є оригінальний бекап цього кліпу в стеку! Не створюємо дублікат із ключами трекера поверх чистого бекапу.
                backupKeysCount = 0;
            } else {
                var touchScale = !!scaleProp && (doScale || (applyMode === 'center' && params.autoZoomScale && params.autoZoomScale > 100));
                backupEntry = {
                    nodeId:     '',
                    clipName:   '',
                    trackIndex: trackIndex,
                    clipIndex:  clipIndex,
                    clipStart:  0,
                    pos:        (doPos && posProp) ? _snapshotProp(posProp) : null,
                    scale:      touchScale ? _snapshotProp(scaleProp) : null,
                    scaleWidth: (touchScale && scaleWidthProp) ? _snapshotProp(scaleWidthProp) : null,
                    rot:        (doRot && rotProp) ? _snapshotProp(rotProp) : null,
                    uniform:    null
                };
                try { backupEntry.nodeId = clip.nodeId || ''; } catch (eBn) {}
                try { backupEntry.clipName = clip.name || ''; } catch (eBc) {}
                try { if (clip.start) backupEntry.clipStart = _getTimeSecondsSafe(clip.start); } catch (eBs) {}
                if (uniformScaleProp) { try { backupEntry.uniform = uniformScaleProp.getValue(); } catch (eBu) {} }
                backupKeysCount = (backupEntry.pos ? backupEntry.pos.keys.length : 0) +
                                  (backupEntry.scale ? backupEntry.scale.keys.length : 0) +
                                  (backupEntry.scaleWidth ? backupEntry.scaleWidth.keys.length : 0) +
                                  (backupEntry.rot ? backupEntry.rot.keys.length : 0);
                backupStack.push(backupEntry);
                backupEntryPushed = true;
                while (backupStack.length > _AT_BACKUP_MAX) backupStack.shift();
            }
        }

        // Очищення попередніх ключових кадрів за O(1) через setTimeVarying(false) перед setTimeVarying(true),
        // щоб повторні запуски трекінгу (3-4+ разів поспіль) не накопичували тисячі старих ключів у Premiere Pro
        // Uniform Scale вимикається ЛИШЕ за явним запитом (прапорець «Анізотропний масштаб» / пресет).
        // Раніше достатньо було мінімальної різниці scaleX/scaleY у ключах трекера (шум), щоб Premiere перейшов
        // на окремі Scale Width / Scale Height: у зменшеного шару з застарілим Scale Width це розтягувало картинку по ширині.
        var hasAnisotropicData = (doScale && params.anisotropicScale === true);

        var isUniformScaleOn = true;
        if (hasAnisotropicData && uniformScaleProp) {
            try {
                uniformScaleProp.setValue(false);
                isUniformScaleOn = false;
            } catch (eDisUni) {
                try {
                    uniformScaleProp.setValue(0);
                    isUniformScaleOn = false;
                } catch (eDisUni2) {}
            }
            // Щойно розблокований Scale Width містить застаріле значення: вирівнюємо його з поточним масштабом шару
            if (!isUniformScaleOn && uniformOnAtStart && scaleWidthProp) {
                try {
                    if (typeof scaleWidthProp.isTimeVarying === "function" && scaleWidthProp.isTimeVarying()) {
                        scaleWidthProp.setTimeVarying(false);
                    }
                } catch (eSyncW0) {}
                _syncScaleWidthValue(scaleWidthProp, initLayerScale);
            }
        } else if (uniformScaleProp) {
            try {
                var uv = uniformScaleProp.getValue();
                if (uv === false || uv === 0 || uv === "false" || uv === "0") {
                    isUniformScaleOn = false;
                }
            } catch (eUv) {}
        }

        // Шар, який після запусків старих версій лишився з вимкненим Uniform Scale і застарілою шириною (наприклад Scale Height 11.7
        // при Scale Width 99.2), без явного запиту анізотропного масштабу повертаємо до пропорційного. Висота (Scale) вважається
        // правильною: саме її користувач виставляв вручну. Інакше ширина й далі множилась би від застарілого значення.
        var uniformNormalized = false;
        if (doScale && !hasAnisotropicData && !isUniformScaleOn && uniformScaleProp && scaleWidthProp && scaleProp &&
            Math.abs(initLayerScaleX - initLayerScaleY) > Math.max(1.0, initLayerScaleY * 0.02)) {
            try {
                if (typeof scaleWidthProp.isTimeVarying === "function" && scaleWidthProp.isTimeVarying()) {
                    scaleWidthProp.setTimeVarying(false);
                }
            } catch (eNormW0) {}
            _syncScaleWidthValue(scaleWidthProp, initLayerScaleY);
            try { uniformScaleProp.setValue(true, true); } catch (eNormU1) {
                try { uniformScaleProp.setValue(true); } catch (eNormU2) {}
            }
            try {
                var uvN = uniformScaleProp.getValue();
                if (!(uvN === false || uvN === 0 || uvN === "false" || uvN === "0")) {
                    isUniformScaleOn = true;
                    uniformNormalized = true;
                    initLayerScaleX = initLayerScale;
                }
            } catch (eNormU3) {}
        }

        if (doPos && posProp) {
            try {
                if (typeof posProp.isTimeVarying === "function" && posProp.isTimeVarying()) {
                    posProp.setTimeVarying(false);
                }
            } catch (eClrPos) {}
            try { posProp.setTimeVarying(true); } catch (e) {}
        }
        if (doScale && scaleProp) {
            try {
                if (typeof scaleProp.isTimeVarying === "function" && scaleProp.isTimeVarying()) {
                    scaleProp.setTimeVarying(false);
                }
            } catch (eClrSc) {}
            try { scaleProp.setTimeVarying(true); } catch (e) {}

            if (!isUniformScaleOn && scaleWidthProp) {
                try {
                    if (typeof scaleWidthProp.isTimeVarying === "function" && scaleWidthProp.isTimeVarying()) {
                        scaleWidthProp.setTimeVarying(false);
                    }
                } catch (eClrScW) {}
                try { scaleWidthProp.setTimeVarying(true); } catch (e) {}
            }
        }
        if (doRot && rotProp) {
            try {
                if (typeof rotProp.isTimeVarying === "function" && rotProp.isTimeVarying()) {
                    rotProp.setTimeVarying(false);
                }
            } catch (eClrRot) {}
            try { rotProp.setTimeVarying(true); } catch (e) {}
        }

        // Auto-Zoom to Fill для Lock-on Center:
        // Автоматично збільшує базовий масштаб кліпу, щоб усунути чорні рамки по краях епізоду
        if (applyMode === 'center' && params.autoZoomScale && params.autoZoomScale > 100) {
            var baseAutoZoom = Number(params.autoZoomScale);
            initLayerScale = baseAutoZoom;
            initLayerScaleX = baseAutoZoom;
            initLayerScaleY = baseAutoZoom;
            if (!doScale && scaleProp) {
                try {
                    if (typeof scaleProp.isTimeVarying === "function" && scaleProp.isTimeVarying()) {
                        scaleProp.setTimeVarying(false);
                    }
                    scaleProp.setValue(baseAutoZoom);
                } catch (eAzS) {}
                if (!isUniformScaleOn && scaleWidthProp) {
                    try {
                        if (typeof scaleWidthProp.isTimeVarying === "function" && scaleWidthProp.isTimeVarying()) {
                            scaleWidthProp.setTimeVarying(false);
                        }
                        scaleWidthProp.setValue(baseAutoZoom);
                    } catch (eAzSW) {}
                }
            }
        }

        var firstKfX = (keyframes[0] && _isNum(keyframes[0].x)) ? keyframes[0].x : 0;
        var firstKfY = (keyframes[0] && _isNum(keyframes[0].y)) ? keyframes[0].y : 0;
        var firstKfScale = (keyframes[0] && isFinite(keyframes[0].scale) && keyframes[0].scale > 0) ? keyframes[0].scale : 100;
        var firstKfScaleX = (keyframes[0] && isFinite(keyframes[0].scaleX) && keyframes[0].scaleX > 0) ? keyframes[0].scaleX : firstKfScale;
        var firstKfScaleY = (keyframes[0] && isFinite(keyframes[0].scaleY) && keyframes[0].scaleY > 0) ? keyframes[0].scaleY : firstKfScale;
        var firstKfRot   = (keyframes[0] && keyframes[0].rotation !== undefined && isFinite(keyframes[0].rotation)) ? keyframes[0].rotation : 0;
        var useRelative = (params.relativeOffset !== false);

        var initOffX = initLayerX - (firstKfX * scaleRatioX);
        var initOffY = initLayerY - (firstKfY * scaleRatioY);

        var setScaleWithFallback = function(prop, keyVal, sNum, lastFlag) {
            try {
                prop.setValueAtKey(keyVal, sNum, lastFlag);
                return true;
            } catch (e1) {
                try {
                    prop.setValueAtKey(keyVal, sNum);
                    return true;
                } catch (e2) {
                    try {
                        prop.setValueAtKey(keyVal, [sNum, sNum], lastFlag);
                        return true;
                    } catch (e3) {
                        try {
                            prop.setValueAtKey(keyVal, [sNum, sNum]);
                            return true;
                        } catch (e4) {
                            return false;
                        }
                    }
                }
            }
        };

        // Кліповий таймінг
        var clipStartSec = 0;
        var clipInSec    = 0;
        var clipInTicks  = "0";
        var clipSpeedVal = 1.0;
        try { if (clip.start) clipStartSec = clip.start.seconds; } catch (eSt) {}
        try {
            if (clip.inPoint) {
                clipInSec = clip.inPoint.seconds;
                if (clip.inPoint.ticks) clipInTicks = String(clip.inPoint.ticks);
            }
        } catch (eIn2) {}
        try { if (clip.getSpeed) clipSpeedVal = clip.getSpeed(); } catch (eSpd2) {}
        var applySpeedMul = (clipSpeedVal && isFinite(clipSpeedVal) && clipSpeedVal > 0) ? (clipSpeedVal > 20 ? (clipSpeedVal / 100.0) : clipSpeedVal) : 1.0;

        var tickRate = 254016000000;
        var seqFrameTicks = 0;
        try {
            var seqSettings = (seq && seq.getSettings) ? seq.getSettings() : null;
            if (seqSettings && seqSettings.videoFrameRate && seqSettings.videoFrameRate.ticks) {
                seqFrameTicks = parseFloat(seqSettings.videoFrameRate.ticks);
            }
        } catch (eSeqTk) {}

        var baseInTicksNum = parseFloat(clipInTicks) || Math.round(clipInSec * tickRate);

        var firstError = null;
        var lastGoodX = firstKfX;
        var lastGoodY = firstKfY;
        var lastGoodKfRot = 0;
        var count = 0;
        var reusableTime = null;
        try { reusableTime = new Time(); } catch (eInitTime) { reusableTime = null; }

        for (var k = 0; k < keyframes.length; k++) {
            if (k > 0 && k % 250 === 0) {
                try { if (typeof $ !== 'undefined' && $.gc) $.gc(); } catch (eGc) {}
            }
            var kf = keyframes[k];
            var isLast = (k === keyframes.length - 1);
            try {
                // Некоректна точка (null/NaN/Infinity) не повинна кидати шар у кут кадру: утримуємо останню коректну
                var kfX = (kf && _isNum(kf.x)) ? kf.x : lastGoodX;
                var kfY = (kf && _isNum(kf.y)) ? kf.y : lastGoodY;
                lastGoodX = kfX;
                lastGoodY = kfY;

                var offsetSec = (kf.time - clipStartSec) * applySpeedMul;
                var clipLocalSec = clipInSec + offsetSec;
                if (clipLocalSec < 0) clipLocalSec = 0;

                var rawDeltaTicks = offsetSec * tickRate;
                if (seqFrameTicks > 0) {
                    rawDeltaTicks = Math.round(rawDeltaTicks / seqFrameTicks) * seqFrameTicks;
                }
                var kfTicks = String(Math.round(baseInTicksNum + rawDeltaTicks));

                var t = reusableTime;
                if (t) {
                    try {
                        t.seconds = clipLocalSec;
                        try { t.ticks = kfTicks; } catch (eTk) {}
                    } catch (eTime) {
                        t = null;
                    }
                }

                // 1. Обертання (Rotation)
                var kfRot = _isNum(kf.rotation) ? (kf.rotation - firstKfRot) : lastGoodKfRot;
                lastGoodKfRot = kfRot;
                var targetRot = 0;
                if (applyMode === 'center') {
                    targetRot = initLayerRot - kfRot;
                } else {
                    targetRot = useRelative ? (initLayerRot + kfRot) : kfRot;
                }
                targetRot = Math.round(targetRot * 100) / 100;

                // 2. Масштаб (Scale)
                var currentKfScale = (kf.scale !== undefined && isFinite(kf.scale) && kf.scale > 0) ? kf.scale : firstKfScale;
                var currentKfScaleX = (kf.scaleX !== undefined && isFinite(kf.scaleX) && kf.scaleX > 0) ? kf.scaleX : currentKfScale;
                var currentKfScaleY = (kf.scaleY !== undefined && isFinite(kf.scaleY) && kf.scaleY > 0) ? kf.scaleY : currentKfScale;

                var scRatio = (firstKfScale > 0) ? (currentKfScale / firstKfScale) : 1;
                if (scRatio < 0.1) scRatio = 0.1;
                if (scRatio > 10.0) scRatio = 10.0;

                var scRatioX = (firstKfScaleX > 0) ? (currentKfScaleX / firstKfScaleX) : scRatio;
                if (scRatioX < 0.1) scRatioX = 0.1;
                if (scRatioX > 10.0) scRatioX = 10.0;

                var scRatioY = (firstKfScaleY > 0) ? (currentKfScaleY / firstKfScaleY) : scRatio;
                if (scRatioY < 0.1) scRatioY = 0.1;
                if (scRatioY > 10.0) scRatioY = 10.0;

                var targetScale = initLayerScale;
                var targetScaleX = initLayerScaleX;
                var targetScaleY = initLayerScaleY;

                if (applyMode === 'center') {
                    targetScale = initLayerScale / scRatio;
                    if (targetScale < 1.0) targetScale = 1.0;
                    if (targetScale > 1000.0) targetScale = 1000.0;

                    targetScaleX = initLayerScaleX / scRatioX;
                    if (targetScaleX < 1.0) targetScaleX = 1.0;
                    if (targetScaleX > 1000.0) targetScaleX = 1000.0;

                    targetScaleY = initLayerScaleY / scRatioY;
                    if (targetScaleY < 1.0) targetScaleY = 1.0;
                    if (targetScaleY > 1000.0) targetScaleY = 1000.0;
                } else {
                    targetScale = useRelative ? (initLayerScale * scRatio) : currentKfScale;
                    if (targetScale < 1.0) targetScale = 1.0;
                    if (targetScale > 10000.0) targetScale = 10000.0;

                    targetScaleX = useRelative ? (initLayerScaleX * scRatioX) : currentKfScaleX;
                    if (targetScaleX < 1.0) targetScaleX = 1.0;
                    if (targetScaleX > 10000.0) targetScaleX = 10000.0;

                    targetScaleY = useRelative ? (initLayerScaleY * scRatioY) : currentKfScaleY;
                    if (targetScaleY < 1.0) targetScaleY = 1.0;
                    if (targetScaleY > 10000.0) targetScaleY = 10000.0;
                }
                targetScale = Math.round(targetScale * 100) / 100;
                targetScaleX = Math.round(targetScaleX * 100) / 100;
                targetScaleY = Math.round(targetScaleY * 100) / 100;

                // 3. Позиція (Position)
                var targetX = 0;
                var targetY = 0;
                if (applyMode === 'center') {
                    // Режим центрування на об'єкті (Lock-on Center / Стабілізація на об'єкті):
                    // Відео зміщується так, щоб обрана точка завжди залишалася точно по центру кадру секвенції (seqW / 2, seqH / 2)
                    // з урахуванням поточного масштабу, обертання та точки прив'язки (Anchor Point)
                    var activeScale = (doScale && scaleProp) ? (targetScale / 100) : (initLayerScale / 100);
                    var activeScaleX = (doScale && scaleProp) ? ((!isUniformScaleOn && scaleWidthProp) ? (targetScaleX / 100) : activeScale) : (initLayerScaleX / 100);
                    var activeScaleY = (doScale && scaleProp) ? (targetScaleY / 100) : (initLayerScaleY / 100);
                    var activeRot   = (doRot && rotProp) ? targetRot : initLayerRot;
                    var rotRad = (activeRot * Math.PI) / 180;
                    var cosR = Math.cos(rotRad);
                    var sinR = Math.sin(rotRad);

                    var dx = (kfX - initAnchorX) * scaleRatioX;
                    var dy = (kfY - initAnchorY) * scaleRatioY;

                    var xPrime = activeScaleX * dx * cosR - activeScaleY * dy * sinR;
                    var yPrime = activeScaleX * dx * sinR + activeScaleY * dy * cosR;

                    targetX = (seqW / 2) - xPrime;
                    targetY = (seqH / 2) - yPrime;
                } else {
                    if (useRelative) {
                        // ATTACH-режим: шар слідує за точкою трекера.
                        // Масштабує та обертає початковий вектор зміщення (захист від вильоту тексту)
                        var activeScRatioX = (doScale && scaleProp) ? ((!isUniformScaleOn && scaleWidthProp) ? scRatioX : scRatio) : 1.0;
                        var activeScRatioY = (doScale && scaleProp) ? scRatioY : 1.0;
                        var activeKfRot = (doRot && rotProp) ? kfRot : 0;
                        var rotRadA = (activeKfRot * Math.PI) / 180;
                        var cosRA = Math.cos(rotRadA);
                        var sinRA = Math.sin(rotRadA);

                        var scaledRotOffX = activeScRatioX * (cosRA * initOffX - sinRA * initOffY);
                        var scaledRotOffY = activeScRatioY * (sinRA * initOffX + cosRA * initOffY);

                        targetX = (kfX * scaleRatioX) + scaledRotOffX;
                        targetY = (kfY * scaleRatioY) + scaledRotOffY;
                    } else {
                        targetX = (kfX * scaleRatioX);
                        targetY = (kfY * scaleRatioY);
                    }
                }
                var outX = 0;
                var outY = 0;
                if (originalIsNormalized) {
                    outX = Math.round((targetX / seqW) * 100000) / 100000;
                    outY = Math.round((targetY / seqH) * 100000) / 100000;
                } else {
                    outX = Math.round(targetX * 100) / 100;
                    outY = Math.round(targetY * 100) / 100;
                }

                // Запис позиції
                if (doPos && posProp) {
                    var posAdded = false;
                    if (t) {
                        try {
                            posProp.addKey(t);
                            posProp.setValueAtKey(t, [outX, outY], isLast);
                            posAdded = true;
                        } catch (eT) {}
                    }
                    if (!posAdded) {
                        try {
                            posProp.addKey(clipLocalSec);
                            posProp.setValueAtKey(clipLocalSec, [outX, outY], isLast);
                            posAdded = true;
                        } catch (eSec) {
                            try {
                                posProp.addKey(clipLocalSec);
                                posProp.setValueAtKey(clipLocalSec, [outX, outY]);
                                posAdded = true;
                            } catch (eKf) {
                                if (!firstError) firstError = "Pos: " + String(eKf.message || eKf);
                            }
                        }
                    }
                }

                // Запис масштабу
                if (doScale && scaleProp) {
                    var scaleAdded = false;
                    var effScaleY = (!isUniformScaleOn && scaleWidthProp) ? targetScaleY : targetScale;
                    var effScaleX = (!isUniformScaleOn && scaleWidthProp) ? targetScaleX : targetScale;

                    if (t) {
                        try {
                            scaleProp.addKey(t);
                            if (setScaleWithFallback(scaleProp, t, effScaleY, isLast)) {
                                scaleAdded = true;
                            }
                        } catch (eTSc) {}
                    }
                    if (!scaleAdded) {
                        try {
                            scaleProp.addKey(clipLocalSec);
                            if (setScaleWithFallback(scaleProp, clipLocalSec, effScaleY, isLast)) {
                                scaleAdded = true;
                            }
                        } catch (eSecSc) {
                            try {
                                scaleProp.addKey(clipLocalSec);
                                if (setScaleWithFallback(scaleProp, clipLocalSec, effScaleY, false)) {
                                    scaleAdded = true;
                                }
                            } catch (eKfSc) {
                                if (!firstError) firstError = "Scale: " + String(eKfSc.message || eKfSc);
                            }
                        }
                    }

                    // Якщо Uniform Scale вимкнено або anisotropicScale: записуємо effScaleX у scaleWidthProp (ADBE Scale Width)
                    if (!isUniformScaleOn && scaleWidthProp) {
                        if (t) {
                            try {
                                scaleWidthProp.addKey(t);
                                setScaleWithFallback(scaleWidthProp, t, effScaleX, isLast);
                            } catch (eTScW) {}
                        } else {
                            try {
                                scaleWidthProp.addKey(clipLocalSec);
                                setScaleWithFallback(scaleWidthProp, clipLocalSec, effScaleX, isLast);
                            } catch (eSecScW) {
                                try {
                                    scaleWidthProp.addKey(clipLocalSec);
                                    setScaleWithFallback(scaleWidthProp, clipLocalSec, effScaleX, false);
                                } catch (eKfScW) {}
                            }
                        }
                    }
                }

                // Запис обертання
                if (doRot && rotProp) {
                    var rotAdded = false;
                    if (t) {
                        try {
                            rotProp.addKey(t);
                            rotProp.setValueAtKey(t, targetRot, isLast);
                            rotAdded = true;
                        } catch (eTRot) {}
                    }
                    if (!rotAdded) {
                        try {
                            rotProp.addKey(clipLocalSec);
                            rotProp.setValueAtKey(clipLocalSec, targetRot, isLast);
                            rotAdded = true;
                        } catch (eSecRot) {
                            try {
                                rotProp.addKey(clipLocalSec);
                                rotProp.setValueAtKey(clipLocalSec, targetRot);
                                rotAdded = true;
                            } catch (eKfRot) {
                                if (!firstError) firstError = "Rotation: " + String(eKfRot.message || eKfRot);
                            }
                        }
                    }
                }

                count++;
            } catch (eLoop) {
                if (!firstError) firstError = "Loop: " + String(eLoop.message || eLoop);
            }
        }

        // Перевірка збережених ключів (тільки для активних властивостей)
        var posKeysCount = 0;
        var pk = null;
        if (doPos && posProp) {
            try {
                pk = posProp.getKeys();
                if (pk) posKeysCount = pk.length;
            } catch (eK) {}
        }

        var scaleKeysCount = 0;
        if (doScale && scaleProp) {
            try {
                var sk = scaleProp.getKeys();
                if (sk) scaleKeysCount = sk.length;
                sk = null;
            } catch (eK2) {}
        }

        // Захист від розтягування: якщо ми вимкнули Uniform Scale, а Scale Width не прийняв ключі (так буває в Premiere на деяких
        // системах), шар отримав би нову висоту й стару (застарілу) ширину. Тоді повертаємо Uniform Scale — масштаб лишається рівномірним.
        var uniformRestoredByGuard = false;
        if (doScale && !isUniformScaleOn && uniformOnAtStart && scaleWidthProp && uniformScaleProp && scaleKeysCount > 0) {
            var scaleWidthKeysCount = 0;
            try {
                var swk = scaleWidthProp.getKeys();
                if (swk) scaleWidthKeysCount = swk.length;
                swk = null;
            } catch (eSwk) {}
            if (scaleWidthKeysCount < scaleKeysCount) {
                try { uniformScaleProp.setValue(true, true); } catch (eUg1) {
                    try { uniformScaleProp.setValue(true); } catch (eUg2) {}
                }
                isUniformScaleOn = true;
                uniformRestoredByGuard = true;
            }
        }

        var rotKeysCount = 0;
        if (doRot && rotProp) {
            try {
                var rk = rotProp.getKeys();
                if (rk) rotKeysCount = rk.length;
                rk = null;
            } catch (eK3) {}
        }

        var posVerified = !doPos || !posProp || (typeof posProp.getKeys !== "function") || (posKeysCount > 0);
        var scaleVerified = !doScale || !scaleProp || (typeof scaleProp.getKeys !== "function") || (scaleKeysCount > 0);
        var rotVerified = !doRot || !rotProp || (typeof rotProp.getKeys !== "function") || (rotKeysCount > 0);

        if (!posVerified || !scaleVerified || !rotVerified || count === 0) {
            pk = null;
            reusableTime = null;
            try { $.gc(); } catch (eGcErr) {}
            if (backupStack && backupStack.length > 0 && backupEntryPushed && backupEntry) {
                backupStack.pop();
                try {
                    if (posProp && backupEntry.pos) _restorePropFromSnapshot(posProp, backupEntry.pos);
                    _restoreScaleProps(uniformScaleProp, scaleProp, scaleWidthProp, backupEntry);
                    if (rotProp && backupEntry.rot) _restorePropFromSnapshot(rotProp, backupEntry.rot);
                } catch (eRollback) {}
            }
            if (isStill) {
                return _err("STILL_IMAGE_NEST_REQUIRED");
            }
            return _err("KEYS_NOT_RECORDED", firstError || "");
        }

        var firstPosVal = null;
        var lastPosVal  = null;
        try {
            if (pk && pk.length > 0) {
                firstPosVal = posProp.getValueAtKey(pk[0]);
                lastPosVal  = posProp.getValueAtKey(pk[pk.length - 1]);
            }
        } catch (eDbg) {}

        var targetClipNameOut = clip.name;
        pk = null;
        reusableTime = null;
        keyframes = null;
        params = null;
        try { $.gc(); } catch (eGc) {}

        return _v({
            success:        true,
            targetClipName: targetClipNameOut,
            trackIndex:     trackIndex,
            count:          Math.max(posKeysCount, scaleKeysCount, rotKeysCount, count),
            posKeys:        posKeysCount,
            scaleKeys:      scaleKeysCount,
            rotKeys:        rotKeysCount,
            firstPosVal:    firstPosVal,
            lastPosVal:     lastPosVal,
            prevKeys:       backupKeysCount,
            uniformKept:    uniformRestoredByGuard,
            uniformNormalized: uniformNormalized,
            hostVersion:    AT_HOSTSCRIPT_VERSION,
            backupDepth:    _atBackupStack().length
        });

    } catch (e) {
        return _err("EX_APPLY_KEYFRAMES", String(e));
    }
}

function getSequenceSettings() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var fps = 25;
        var width = 1920;
        var height = 1080;
        try {
            var settings = seq.getSettings();
            if (settings && settings.videoFrameRate && settings.videoFrameRate.ticks) {
                var sTicks = parseFloat(settings.videoFrameRate.ticks);
                if (sTicks > 0) {
                    fps = 254016000000 / sTicks;
                }
            }
            if (isNaN(fps) || !isFinite(fps) || fps <= 0) fps = 25;
            if (settings && settings.videoFrameWidth) width = settings.videoFrameWidth;
            if (settings && settings.videoFrameHeight) height = settings.videoFrameHeight;
        } catch (eSettings) { fps = 25; }

        return _v({
            name:   seq.name || "Sequence",
            fps:    fps,
            width:  width,
            height: height
        });

    } catch (e) {
        return _err("EX_SETTINGS", String(e));
    }
}

// Global and $ export
try {
    $.getSelectedClipInfo  = getSelectedClipInfo;
    $.getSelectedLayerInfo = getSelectedLayerInfo;
    $.getPlayheadTime      = getPlayheadTime;
    $.setPlayheadTime      = setPlayheadTime;
    $.applyKeyframesToClip = applyKeyframesToClip;
    $.getSequenceSettings  = getSequenceSettings;
    $.restoreLastKeyframesBackup = restoreLastKeyframesBackup;
    $.getKeyframesBackupDepth    = getKeyframesBackupDepth;
} catch (e) {}

"AutoTracker HostScript Loaded";
