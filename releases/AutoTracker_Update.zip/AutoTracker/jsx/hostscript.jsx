// hostscript.jsx - ExtendScript (ES3) for Auto-Tracker CEP Plugin
// Pure ES3 compatible

// =========================================================================
// Embedded json2.js (Douglas Crockford, Public Domain)
// Pure ES3 JSON polyfill — zero external dependencies
// =========================================================================
var JSON;
if (!JSON) {
    JSON = {};
}
(function () {
    'use strict';

    var rx_one = /^[\],:{}\s]*$/;
    var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
    var rx_three = /(?:"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g;
    var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
    var rx_escapable = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

    function f(n) {
        return n < 10 ? '0' + n : n;
    }

    function this_value() {
        return this.valueOf();
    }

    if (typeof Date.prototype.toJSON !== 'function') {
        Date.prototype.toJSON = function () {
            return isFinite(this.valueOf())
                ? this.getUTCFullYear() + '-' +
                        f(this.getUTCMonth() + 1) + '-' +
                        f(this.getUTCDate()) + 'T' +
                        f(this.getUTCHours()) + ':' +
                        f(this.getUTCMinutes()) + ':' +
                        f(this.getUTCSeconds()) + 'Z'
                : null;
        };
        Boolean.prototype.toJSON  = this_value;
        Number.prototype.toJSON   = this_value;
        String.prototype.toJSON   = this_value;
    }

    var gap;
    var indent;
    var meta;
    var rep;

    function quote(string) {
        rx_escapable.lastIndex = 0;
        return rx_escapable.test(string) ? '"' + string.replace(rx_escapable, function (a) {
            var c = meta[a];
            return typeof c === 'string' ? c : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
        }) + '"' : '"' + string + '"';
    }

    function str(key, holder) {
        var i;
        var k;
        var v;
        var length;
        var mind = gap;
        var partial;
        var value = holder[key];

        if (value && typeof value === 'object' && typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }
        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }
        switch (typeof value) {
        case 'string':
            return quote(value);
        case 'number':
            return isFinite(value) ? String(value) : 'null';
        case 'boolean':
        case 'null':
            return String(value);
        case 'object':
            if (!value) { return 'null'; }
            gap += indent;
            partial = [];
            if (Object.prototype.toString.apply(value) === '[object Array]') {
                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }
                v = partial.length === 0 ? '[]' : gap ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']' : '[' + partial.join(',') + ']';
                gap = mind;
                return v;
            }
            if (rep && typeof rep === 'object') {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    if (typeof rep[i] === 'string') {
                        k = rep[i];
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            } else {
                for (k in value) {
                    if (Object.prototype.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            }
            v = partial.length === 0 ? '{}' : gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}' : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
        }
    }

    if (typeof JSON.stringify !== 'function') {
        meta = {
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"': '\\"',
            '\\': '\\\\'
        };
        JSON.stringify = function (value, replacer, space) {
            var i;
            gap = '';
            indent = '';
            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) { indent += ' '; }
            } else if (typeof space === 'string') {
                indent = space;
            }
            rep = replacer;
            if (replacer && typeof replacer !== 'function' && (typeof replacer !== 'object' || typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }
            return str('', {'': value});
        };
    }

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text, reviver) {
            var j;
            function walk(holder, key) {
                var k;
                var v;
                var value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver ? reviver.call(holder, key, value) : value;
            }
            text = String(text);
            rx_dangerous.lastIndex = 0;
            if (rx_dangerous.test(text)) {
                text = text.replace(rx_dangerous, function (a) {
                    return '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }
            if (rx_one.test(text.replace(rx_two, '@').replace(rx_three, ']').replace(rx_four, ''))) {
                j = eval('(' + text + ')');
                return typeof reviver === 'function' ? walk({'': j}, '') : j;
            }
            throw new SyntaxError('JSON.parse');
        };
    }
}());
if (typeof $ !== 'undefined' && $.global && !$.global.JSON) {
    $.global.JSON = JSON;
}

function _v(val) {
    if (val === null || val === undefined) return 'null';
    if (typeof val === 'boolean') return String(val);
    if (typeof val === 'number') return (!isFinite(val) || isNaN(val)) ? 'null' : String(val);
    if (typeof val === 'string') {
        return '"' + val.replace(/\\/g, '\\\\').replace(/"/g, '\\"')
                        .replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
    }
    if (val instanceof Array || Object.prototype.toString.call(val) === '[object Array]') {
        var items = [];
        for (var ai = 0; ai < val.length; ai++) items.push(_v(val[ai]));
        return '[' + items.join(',') + ']';
    }
    var parts = [];
    for (var k in val) {
        if (val.hasOwnProperty(k)) parts.push('"' + k + '":' + _v(val[k]));
    }
    return '{' + parts.join(',') + '}';
}

function _err(code, detail) {
    return _v({ error: code, detail: detail || '' });
}

function _parse(jsonStr) {
    if (!jsonStr) return null;
    if (jsonStr.length > 2048) {
        try {
            return eval('(' + jsonStr + ')');
        } catch (eFast) {}
    }
    try {
        if (typeof JSON !== 'undefined' && JSON.parse) {
            return JSON.parse(jsonStr);
        }
    } catch (ej) {}
    try {
        return eval('(' + jsonStr + ')');
    } catch(e) {
        return null;
    }
}

function _cleanMediaPath(raw) {
    if (!raw) return "";
    var s = String(raw);
    try { s = decodeURI(s); } catch (e) {}
    s = s.replace(/^file:\/\/\/?([a-zA-Z]:)/i, '$1');
    s = s.replace(/^file:\/\//i, '');
    return s;
}

function _getMotionComponentAndProps(clip) {
    var motionComp = null;
    var posProp = null;
    var scaleProp = null;
    var rotProp = null;
    var anchorProp = null;
    if (!clip) return { motionComp: null, posProp: null, scaleProp: null, rotProp: null, anchorProp: null };
    try {
        var comps = clip.components;
        if (comps) {
            var numComps = (comps.numItems !== undefined) ? comps.numItems : (comps.length || 0);
            for (var c = 0; c < numComps; c++) {
                var comp = comps[c];
                var mName = "";
                var dName = "";
                try { if (comp.matchName) mName = comp.matchName; } catch (em) {}
                try { if (comp.displayName) dName = comp.displayName; } catch (ed) {}
                if (mName === "ADBE Motion" || mName === "AE.ADBE Motion" || mName.indexOf("Motion") !== -1 ||
                    dName === "Motion" || dName === "Trajectoire" || dName === "Bewegung" ||
                    dName === "Movimiento" || dName === "Movimento" || dName === "Рух" ||
                    dName === "Позиція" || dName === "Положення" ||
                    dName === "モーション" || dName === "运动") {
                    motionComp = comp;
                    break;
                }
            }
            if (!motionComp && numComps > 0) {
                motionComp = comps[0];
            }
        }
    } catch (eComp) {}

    if (motionComp) {
        try {
            var props = motionComp.properties;
            if (props) {
                var numProps = (props.numItems !== undefined) ? props.numItems : (props.length || 0);
                for (var p = 0; p < numProps; p++) {
                    var prop = props[p];
                    var pmName = "";
                    var pdName = "";
                    try { if (prop.matchName) pmName = prop.matchName; } catch (epm) {}
                    try { if (prop.displayName) pdName = prop.displayName; } catch (epd) {}

                    if (pmName === "ADBE Position" || pmName.indexOf("Position") !== -1 ||
                        pdName === "Position" || pdName === "Posición" || pdName === "Posizione" ||
                        pdName === "Позиція" || pdName === "Положення" || pdName === "位置") {
                        posProp = prop;
                    }
                    if (pmName === "ADBE Scale" || pmName.indexOf("Scale") !== -1 ||
                        pdName === "Scale" || pdName === "Échelle" || pdName === "Skalieren" ||
                        pdName === "Escala" || pdName === "Scala" || pdName === "Масштаб" ||
                        pdName === "スケール" || pdName === "缩放") {
                        scaleProp = prop;
                    }
                    if (pmName === "ADBE Rotate" || pmName === "ADBE Rotation" || pmName.indexOf("Rotate") !== -1 || pmName.indexOf("Rotation") !== -1 ||
                        pdName === "Rotation" || pdName === "Rotate" || pdName === "Drehung" || pdName === "Rotación" || pdName === "Rotazione" ||
                        pdName === "Обертання" || pdName === "Поворот" || pdName === "回転" || pdName === "旋转") {
                        rotProp = prop;
                    }
                    if (pmName === "ADBE Anchor Point" || pmName.indexOf("Anchor") !== -1 ||
                        pdName === "Anchor Point" || pdName === "Point d'ancrage" || pdName === "Ankerpunkt" ||
                        pdName === "Punto de anclaje" || pdName === "Punto di ancoraggio" ||
                        pdName === "Точка прив'язки" ||
                        pdName === "アンカーポイント" || pdName === "锚点") {
                        anchorProp = prop;
                    }
                }
                if (!posProp && numProps >= 1) posProp = props[0];
                if (!scaleProp && numProps >= 2) scaleProp = props[1];
                if (!rotProp && numProps >= 5) {
                    for (var rp = 2; rp < numProps; rp++) {
                        var pCand = props[rp];
                        var pcn = "";
                        try { if (pCand.displayName) pcn = pCand.displayName; } catch (eCn) {}
                        if (pcn && (pcn.indexOf("Rot") !== -1 || pcn.indexOf("Поворот") !== -1 || pcn.indexOf("Оберт") !== -1)) {
                            rotProp = pCand;
                            break;
                        }
                    }
                }
            }
        } catch (eProps) {}
    }

    return { motionComp: motionComp, posProp: posProp, scaleProp: scaleProp, rotProp: rotProp, anchorProp: anchorProp };
}

function isSameClip(c1, c2) {
    if (!c1 || !c2) return false;
    if (c1 === c2) return true;
    try {
        if (c1.nodeId && c2.nodeId && c1.nodeId === c2.nodeId) return true;
    } catch (e1) {}
    try {
        if (c1.name === c2.name && 
            c1.start && c2.start && Math.abs(c1.start.seconds - c2.start.seconds) < 0.001) {
            return true;
        }
    } catch (e2) {}
    return false;
}

function getSelectedClipInfo() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var clip = null;
        var selection = null;
        try { selection = seq.getSelection(); } catch (e) { selection = null; }

        if (selection && selection.length > 0) {
            clip = selection[0];
        }

        // Fallback 1: Clip under playhead (if timeline lost focus when clicking CEP panel)
        if (!clip) {
            try {
                var playSec = 0;
                if (seq.getPlayerPosition) {
                    var pPos = seq.getPlayerPosition();
                    if (pPos) {
                        playSec = (pPos.seconds !== undefined) ? pPos.seconds : (typeof pPos === 'number' ? pPos : 0);
                    }
                }
                var numTr = seq.videoTracks.numTracks;
                for (var t = numTr - 1; t >= 0; t--) {
                    var trk = seq.videoTracks[t];
                    if (!trk) continue;
                    if (trk.isLocked && trk.isLocked()) continue;
                    if (trk.isMuted && trk.isMuted()) continue;
                    for (var c = 0; c < trk.clips.numItems; c++) {
                        var candidate = trk.clips[c];
                        if (candidate && candidate.start && candidate.end) {
                            if (playSec >= candidate.start.seconds && playSec < candidate.end.seconds) {
                                clip = candidate;
                                break;
                            }
                        }
                    }
                    if (clip) break;
                }
            } catch (e1) {}
        }

        // Fallback 2: First clip on video track 0
        if (!clip) {
            try {
                if (seq.videoTracks.numTracks > 0 && seq.videoTracks[0].clips.numItems > 0) {
                    clip = seq.videoTracks[0].clips[0];
                }
            } catch (e2) {}
        }

        if (!clip) return _err("NO_CLIP_FOUND");

        var clipName = "Clip";
        try { if (clip.name) clipName = clip.name; } catch (e) {}

        var filePath = "";
        try {
            if (clip.projectItem && clip.projectItem.getMediaPath) {
                filePath = clip.projectItem.getMediaPath() || "";
            }
        } catch (e) { filePath = ""; }

        if (!filePath) {
            try { if (clip.mediaPath) filePath = clip.mediaPath || ""; } catch (e) {}
        }

        // Fallback: search in project bins by clip name
        if (!filePath && clipName) {
            try {
                function _findItemMedia(bin, targetName) {
                    if (!bin) return "";
                    var cnt = 0;
                    try { cnt = bin.children.numItems; } catch(e) { return ""; }
                    for (var bi = 0; bi < cnt; bi++) {
                        var it = bin.children[bi];
                        if (it && it.name === targetName) {
                            var p = "";
                            try { if (it.getMediaPath) p = it.getMediaPath() || ""; } catch(e) {}
                            if (!p) { try { if (it.mediaPath) p = it.mediaPath || ""; } catch(e) {} }
                            if (p) return p;
                        }
                        if (it && it.children && it.children.numItems > 0) {
                            var subP = _findItemMedia(it, targetName);
                            if (subP) return subP;
                        }
                    }
                    return "";
                }
                filePath = _findItemMedia(app.project.rootItem, clipName);
            } catch (e3) {}
        }

        var fps = 25;
        var width = 1920;
        var height = 1080;
        try {
            var settings = seq.getSettings();
            if (settings && settings.videoFrameRate && settings.videoFrameRate.ticks) {
                var ticksNum = parseFloat(settings.videoFrameRate.ticks);
                if (ticksNum > 0) {
                    fps = 254016000000 / ticksNum;
                }
            }
            if (isNaN(fps) || !isFinite(fps) || fps <= 0) fps = 25;
            if (settings && settings.videoFrameWidth) width = settings.videoFrameWidth;
            if (settings && settings.videoFrameHeight) height = settings.videoFrameHeight;
        } catch (eSettings) { fps = 25; }

        filePath = _cleanMediaPath(filePath);

        var dur = 10;
        try {
            if (clip.end && clip.start) dur = Math.max(0.1, clip.end.seconds - clip.start.seconds);
        } catch (eDur) {}

        var inSec = 0;
        var outSec = inSec + dur;
        var startSec = 0;
        var endSec = dur;
        try { inSec = clip.inPoint.seconds; } catch (e) {}
        try { outSec = clip.outPoint.seconds; } catch (e) { outSec = inSec + dur; }
        try { startSec = clip.start.seconds; } catch (e) {}
        try { endSec = clip.end.seconds; } catch (e) {}

        var playheadSec = 0;
        try {
            if (seq.getPlayerPosition) {
                var pPos2 = seq.getPlayerPosition();
                if (pPos2) {
                    playheadSec = (pPos2.seconds !== undefined) ? pPos2.seconds : (typeof pPos2 === 'number' ? pPos2 : 0);
                }
            }
        } catch (ePlay) {}

        var clipPlayheadSec = inSec + Math.max(0, Math.min(outSec - inSec, playheadSec - startSec));

        var trackIndex = 0;
        var clipIndex = 0;
        var found = false;
        try {
            var tracks = seq.videoTracks;
            for (var i = 0; i < tracks.numTracks; i++) {
                var track = tracks[i];
                for (var j = 0; j < track.clips.numItems; j++) {
                    if (isSameClip(track.clips[j], clip)) {
                        trackIndex = i;
                        clipIndex = j;
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }
        } catch (e) {}

        var clipNodeId = "";
        try { if (clip.nodeId) clipNodeId = clip.nodeId; } catch (eNode) {}

        return _v({
            name:            clipName,
            nodeId:          clipNodeId,
            filePath:        filePath,
            inPoint:         inSec,
            outPoint:        outSec,
            startOnTimeline: startSec,
            endOnTimeline:   endSec,
            playheadSeconds: playheadSec,
            sourceFrameTime: clipPlayheadSec,
            trackIndex:      trackIndex,
            clipIndex:       clipIndex,
            fps:             fps,
            width:           width,
            height:          height
        });

    } catch (e) {
        return _err("EX_GET_CLIP", String(e));
    }
}

function getPlayheadTime(clipNodeId) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var playheadSec = 0;
        try {
            if (seq.getPlayerPosition) {
                var pPos = seq.getPlayerPosition();
                if (pPos) {
                    playheadSec = (pPos.seconds !== undefined) ? pPos.seconds : (typeof pPos === 'number' ? pPos : 0);
                }
            }
        } catch (ePlay) {}

        var clip = null;

        // 1. Швидка перевірка поточного виділення (O(1))
        try {
            var sel = seq.getSelection();
            if (sel && sel.length > 0) {
                if (!clipNodeId || (sel[0].nodeId && sel[0].nodeId === clipNodeId)) {
                    clip = sel[0];
                }
            }
        } catch (eSelFast) {}

        // 2. Пошук за clipNodeId, якщо виділений кліп інший
        if (!clip && clipNodeId) {
            try {
                var numTrk = seq.videoTracks.numTracks;
                for (var t1 = 0; t1 < numTrk; t1++) {
                    var trk1 = seq.videoTracks[t1];
                    for (var c1 = 0; c1 < trk1.clips.numItems; c1++) {
                        var candidate1 = trk1.clips[c1];
                        if (candidate1 && candidate1.nodeId && candidate1.nodeId === clipNodeId) {
                            clip = candidate1;
                            break;
                        }
                    }
                    if (clip) break;
                }
            } catch (eNId) {}
        }

        // 3. Fallback: поточне виділення на таймлайні
        if (!clip) {
            try {
                var sel2 = seq.getSelection();
                if (sel2 && sel2.length > 0) clip = sel2[0];
            } catch (eSel) {}
        }

        // 3. Fallback: clip under playhead
        if (!clip) {
            try {
                var numTr = seq.videoTracks.numTracks;
                for (var t = numTr - 1; t >= 0; t--) {
                    var trk = seq.videoTracks[t];
                    for (var c = 0; c < trk.clips.numItems; c++) {
                        var cand = trk.clips[c];
                        if (cand && cand.start && cand.end) {
                            if (playheadSec >= cand.start.seconds && playheadSec < cand.end.seconds) {
                                clip = cand;
                                break;
                            }
                        }
                    }
                    if (clip) break;
                }
            } catch (eClip) {}
        }

        var sourceFrameTime = playheadSec;
        var clipFound = false;
        var inSec = 0;
        var outSec = 10;
        var startSec = 0;
        if (clip) {
            clipFound = true;
            try { inSec = clip.inPoint.seconds; } catch (eIn) {}
            try { outSec = clip.outPoint.seconds; } catch (eOut) {}
            try { startSec = clip.start.seconds; } catch (eSt) {}
            sourceFrameTime = inSec + Math.max(0, Math.min(outSec - inSec, playheadSec - startSec));
        }

        return _v({
            playheadSeconds: playheadSec,
            sourceFrameTime: sourceFrameTime,
            clipFound:       clipFound,
            inPoint:         inSec,
            outPoint:        outSec,
            startOnTimeline: startSec
        });
    } catch (e) {
        return _err("EX_GET_PLAYHEAD", String(e));
    }
}

function getSelectedLayerInfo() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var clip = null;
        var selection = null;
        try { selection = seq.getSelection(); } catch (e) { selection = null; }

        if (selection && selection.length >= 2) {
            clip = selection[1];
        } else if (selection && selection.length === 1) {
            clip = selection[0];
        }

        // Fallback: Check top tracks under playhead
        if (!clip) {
            try {
                var playSec = 0;
                if (seq.getPlayerPosition) {
                    var pPos = seq.getPlayerPosition();
                    if (pPos) {
                        playSec = (pPos.seconds !== undefined) ? pPos.seconds : (typeof pPos === 'number' ? pPos : 0);
                    }
                }
                var numTr = seq.videoTracks.numTracks;
                for (var t = numTr - 1; t >= 1; t--) {
                    var trk = seq.videoTracks[t];
                    if (!trk) continue;
                    if (trk.isLocked && trk.isLocked()) continue;
                    if (trk.isMuted && trk.isMuted()) continue;
                    for (var c = 0; c < trk.clips.numItems; c++) {
                        var candidate = trk.clips[c];
                        if (candidate && candidate.start && candidate.end) {
                            if (playSec >= candidate.start.seconds && playSec < candidate.end.seconds) {
                                clip = candidate;
                                break;
                            }
                        }
                    }
                    if (clip) break;
                }
            } catch (e1) {}
        }

        if (!clip) return _err("NO_TARGET_LAYER_FOUND");

        var clipName = "Target Layer";
        try { if (clip.name) clipName = clip.name; } catch (e) {}

        var startSec = 0;
        var endSec = 0;
        var inSec = 0;
        var outSec = 0;
        try { if (clip.start) startSec = clip.start.seconds; } catch (e) {}
        try { if (clip.end) endSec = clip.end.seconds; } catch (e) {}
        try { if (clip.inPoint) inSec = clip.inPoint.seconds; } catch (e) {}
        try { if (clip.outPoint) outSec = clip.outPoint.seconds; } catch (e) {}

        var trackIndex = 0;
        var clipIndex = 0;
        var found = false;
        try {
            var tracks = seq.videoTracks;
            for (var i = tracks.numTracks - 1; i >= 0; i--) {
                var track = tracks[i];
                for (var j = 0; j < track.clips.numItems; j++) {
                    if (isSameClip(track.clips[j], clip)) {
                        trackIndex = i;
                        clipIndex = j;
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }
        } catch (e) {}

        var clipNodeId = "";
        try { if (clip.nodeId) clipNodeId = clip.nodeId; } catch (eNode2) {}

        var isStill = false;
        try {
            var pi = clip.projectItem;
            if (pi && pi.name && pi.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
                isStill = true;
            }
        } catch (eStill) {}
        if (!isStill && clip.name && clip.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
            isStill = true;
        }

        var curPos = null;
        var curScale = null;
        var layerMotion = _getMotionComponentAndProps(clip);
        if (layerMotion.posProp) {
            try { curPos = layerMotion.posProp.getValue(); } catch (ePosG) {}
        }
        if (layerMotion.scaleProp) {
            try { curScale = layerMotion.scaleProp.getValue(); } catch (eScG) {}
        }

        return _v({
            name:            clipName,
            nodeId:          clipNodeId,
            trackIndex:      trackIndex,
            clipIndex:       clipIndex,
            startOnTimeline: startSec,
            endOnTimeline:   endSec,
            inPoint:         inSec,
            outPoint:        outSec,
            isStill:         isStill,
            curPos:          curPos,
            curScale:        curScale
        });

    } catch (e) {
        return _err("EX_GET_LAYER", String(e));
    }
}

function applyKeyframesToClip(paramsJson) {
    try {
        if (typeof paramsJson === "string") {
            try {
                if (paramsJson.indexOf("%") !== -1) {
                    paramsJson = decodeURIComponent(paramsJson);
                }
            } catch (eDec) {}
        }
        var params = _parse(paramsJson);
        if (!params) return _err("INVALID_JSON_PARAMS");

        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var trackIndex   = params.trackIndex;
        var clipIndex    = params.clipIndex;
        var keyframes    = params.keyframes;
        var doPos        = (params.trackPosition !== false);
        var doScale      = (params.trackScale !== false);
        var doRot        = (params.trackRotation === true);
        var applyMode    = params.applyMode || 'attach';
        var targetNodeId = params.nodeId;
        var targetName   = params.clipName;

        if (!keyframes || keyframes.length === 0) return _err("NO_KEYFRAMES");

        var clip = null;

        // 0. Пріоритет 1: поточне виділення на таймлайні
        try {
            var sel = seq.getSelection();
            if (sel && sel.length > 0) {
                for (var si = 0; si < sel.length; si++) {
                    var sc = sel[si];
                    if (targetNodeId && sc.nodeId && sc.nodeId === targetNodeId) {
                        clip = sc;
                        break;
                    }
                    if (targetName && sc.name && sc.name === targetName) {
                        clip = sc;
                        break;
                    }
                }
            }
        } catch (eSel) {}

        // 1. Пошук по nodeId зверху вниз (від вищих треків до нижчих)
        if (!clip && targetNodeId) {
            try {
                for (var ti = seq.videoTracks.numTracks - 1; ti >= 0; ti--) {
                    var trk = seq.videoTracks[ti];
                    if (!trk || (trk.isLocked && trk.isLocked())) continue;
                    for (var ci = 0; ci < trk.clips.numItems; ci++) {
                        if (trk.clips[ci] && trk.clips[ci].nodeId === targetNodeId) {
                            clip = trk.clips[ci];
                            trackIndex = ti;
                            clipIndex = ci;
                            break;
                        }
                    }
                    if (clip) break;
                }
            } catch (eNode) {}
        }

        // 2. Пошук по назві кліпу (з верифікацією clipStartOnTimeline, якщо задано)
        if (!clip && targetName) {
            try {
                for (var tiN = seq.videoTracks.numTracks - 1; tiN >= 0; tiN--) {
                    var trkN = seq.videoTracks[tiN];
                    if (!trkN || (trkN.isLocked && trkN.isLocked())) continue;
                    for (var ciN = 0; ciN < trkN.clips.numItems; ciN++) {
                        var candN = trkN.clips[ciN];
                        if (candN && candN.name === targetName) {
                            if (params.clipStartOnTimeline !== undefined && candN.start) {
                                if (Math.abs(candN.start.seconds - params.clipStartOnTimeline) > 0.05) {
                                    continue;
                                }
                            }
                            clip = candN;
                            trackIndex = tiN;
                            clipIndex = ciN;
                            break;
                        }
                    }
                    if (clip) break;
                }
            } catch (eName) {}
        }

        // 3. Fallback: по заданому trackIndex та clipIndex
        if (!clip) {
            if (trackIndex >= 0 && trackIndex < seq.videoTracks.numTracks) {
                var tTrack = seq.videoTracks[trackIndex];
                if (tTrack && (!tTrack.isLocked || !tTrack.isLocked())) {
                    if (clipIndex >= 0 && clipIndex < tTrack.clips.numItems) {
                        clip = tTrack.clips[clipIndex];
                    }
                }
            }
        }

        // 4. Fallback: пошук по startOnTimeline зверху вниз (від найвищого треку до 0)
        if (!clip && params.clipStartOnTimeline !== undefined) {
            try {
                for (var ti2 = seq.videoTracks.numTracks - 1; ti2 >= 0; ti2--) {
                    var trk2 = seq.videoTracks[ti2];
                    if (!trk2 || (trk2.isLocked && trk2.isLocked())) continue;
                    for (var ci2 = 0; ci2 < trk2.clips.numItems; ci2++) {
                        var cand = trk2.clips[ci2];
                        if (cand && cand.start && Math.abs(cand.start.seconds - params.clipStartOnTimeline) < 0.05) {
                            clip = cand;
                            trackIndex = ti2;
                            clipIndex = ci2;
                            break;
                        }
                    }
                    if (clip) break;
                }
            } catch (eCand) {}
        }

        if (!clip) return _err("CLIP_NOT_FOUND", "Цільовий шар не знайдено на таймлайні.");

        // Оновлюємо фактичний trackIndex для звіту (лише якщо ще не визначено)
        if (trackIndex < 0) {
            try {
                var foundTrackIdx = false;
                for (var fti = seq.videoTracks.numTracks - 1; fti >= 0; fti--) {
                    var ftrk = seq.videoTracks[fti];
                    for (var fci = 0; fci < ftrk.clips.numItems; fci++) {
                        if (isSameClip(ftrk.clips[fci], clip)) {
                            trackIndex = fti;
                            clipIndex = fci;
                            foundTrackIdx = true;
                            break;
                        }
                    }
                    if (foundTrackIdx) break;
                }
            } catch (eFti) {}
        }

        // Перевірка на статичне зображення (png, jpg тощо)
        var isStill = false;
        try {
            var pi = clip.projectItem;
            if (pi && pi.name && pi.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
                isStill = true;
            }
        } catch (eStill) {}
        if (!isStill && clip.name && clip.name.match(/\.(png|jpg|jpeg|gif|bmp|tif|tiff|psd|ai|svg)$/i)) {
            isStill = true;
        }

        var motionData = _getMotionComponentAndProps(clip);
        var motionComp = motionData.motionComp;
        var posProp    = motionData.posProp;
        var scaleProp  = motionData.scaleProp;
        var rotProp    = motionData.rotProp;
        var anchorProp = motionData.anchorProp;

        if (!motionComp) return _err("MOTION_COMPONENT_NOT_FOUND");

        var seqW = 1920;
        var seqH = 1080;
        try {
            var st = seq.getSettings();
            if (st && st.videoFrameWidth) seqW = st.videoFrameWidth;
            if (st && st.videoFrameHeight) seqH = st.videoFrameHeight;
        } catch (eSeq) {}

        var srcW = (params.sourceWidth && params.sourceWidth > 0) ? params.sourceWidth : seqW;
        var srcH = (params.sourceHeight && params.sourceHeight > 0) ? params.sourceHeight : seqH;
        var scaleRatioX = seqW / srcW;
        var scaleRatioY = seqH / srcH;

        var initLayerX = Math.round(seqW / 2);
        var initLayerY = Math.round(seqH / 2);
        var initLayerScale = 100;
        var initLayerRot = 0;
        var initAnchorX = srcW / 2;
        var initAnchorY = srcH / 2;
        var originalIsNormalized = true;

        // Зчитуємо початкові значення властивостей (якщо шар вже мав ключі з попереднього запуску — беремо значення першого ключа)
        if (posProp) {
            try {
                var curPosVal = null;
                try {
                    if (typeof posProp.isTimeVarying === "function" && posProp.isTimeVarying() && typeof posProp.getKeys === "function") {
                        var oldPosKeys = posProp.getKeys();
                        if (oldPosKeys && oldPosKeys.length > 0) {
                            curPosVal = posProp.getValueAtKey(oldPosKeys[0]);
                        }
                    }
                } catch (eOldPK) {}
                if (curPosVal === null || curPosVal === undefined) {
                    curPosVal = posProp.getValue();
                }
                if (typeof curPosVal === "string") {
                    try { curPosVal = eval('(' + curPosVal + ')'); } catch (eEval) {}
                }
                if (curPosVal && curPosVal.length >= 2) {
                    var rx = parseFloat(curPosVal[0]);
                    var ry = parseFloat(curPosVal[1]);
                    if (!isNaN(rx) && !isNaN(ry)) {
                        if (Math.abs(rx) > 2.0 || Math.abs(ry) > 2.0) {
                            originalIsNormalized = false;
                            initLayerX = rx;
                            initLayerY = ry;
                        } else {
                            originalIsNormalized = true;
                            initLayerX = Math.round(rx * seqW);
                            initLayerY = Math.round(ry * seqH);
                        }
                    }
                }
            } catch (ePosVal) {}
        }

        if (anchorProp) {
            try {
                var curAncVal = anchorProp.getValue();
                if (typeof curAncVal === "string") {
                    try { curAncVal = eval('(' + curAncVal + ')'); } catch (eAncEval) {}
                }
                if (curAncVal && curAncVal.length >= 2) {
                    var ax = parseFloat(curAncVal[0]);
                    var ay = parseFloat(curAncVal[1]);
                    if (!isNaN(ax) && !isNaN(ay)) {
                        if (Math.abs(ax) > 2.0 || Math.abs(ay) > 2.0) {
                            initAnchorX = ax;
                            initAnchorY = ay;
                        } else {
                            initAnchorX = ax * srcW;
                            initAnchorY = ay * srcH;
                        }
                    }
                }
            } catch (eAnc) {}
        }

        if (scaleProp) {
            try {
                var curScVal = null;
                try {
                    if (typeof scaleProp.isTimeVarying === "function" && scaleProp.isTimeVarying() && typeof scaleProp.getKeys === "function") {
                        var oldScKeys = scaleProp.getKeys();
                        if (oldScKeys && oldScKeys.length > 0) {
                            curScVal = scaleProp.getValueAtKey(oldScKeys[0]);
                        }
                    }
                } catch (eOldSK) {}
                if (curScVal === null || curScVal === undefined) {
                    curScVal = scaleProp.getValue();
                }
                if (typeof curScVal === "string") {
                    try {
                        var parsedSc = eval('(' + curScVal + ')');
                        if (parsedSc && parsedSc.length !== undefined && parsedSc.length > 0) {
                            curScVal = parseFloat(parsedSc[0]);
                        } else {
                            curScVal = parseFloat(curScVal);
                        }
                    } catch (eScP) {
                        curScVal = parseFloat(curScVal.replace(/[^0-9.-]/g, ''));
                    }
                } else if (curScVal && curScVal.length !== undefined && curScVal.length > 0) {
                    curScVal = parseFloat(curScVal[0]);
                }
                if (typeof curScVal === "number" && !isNaN(curScVal) && curScVal > 0) {
                    initLayerScale = curScVal;
                }
            } catch (e3) {}
        }

        if (rotProp) {
            try {
                var curRotVal = null;
                try {
                    if (typeof rotProp.isTimeVarying === "function" && rotProp.isTimeVarying() && typeof rotProp.getKeys === "function") {
                        var oldRotKeys = rotProp.getKeys();
                        if (oldRotKeys && oldRotKeys.length > 0) {
                            curRotVal = rotProp.getValueAtKey(oldRotKeys[0]);
                        }
                    }
                } catch (eOldRK) {}
                if (curRotVal === null || curRotVal === undefined) {
                    curRotVal = rotProp.getValue();
                }
                if (typeof curRotVal === "string") {
                    try {
                        var parsedRot = eval('(' + curRotVal + ')');
                        if (parsedRot && parsedRot.length !== undefined && parsedRot.length > 0) {
                            curRotVal = parseFloat(parsedRot[0]);
                        } else {
                            curRotVal = parseFloat(curRotVal);
                        }
                    } catch (eRP) {
                        curRotVal = parseFloat(curRotVal.replace(/[^0-9.-]/g, ''));
                    }
                } else if (curRotVal && curRotVal.length !== undefined && curRotVal.length > 0) {
                    curRotVal = parseFloat(curRotVal[0]);
                }
                if (typeof curRotVal === "number" && !isNaN(curRotVal)) {
                    initLayerRot = curRotVal;
                }
            } catch (eRot) {}
        }

        // Очищення попередніх ключових кадрів за O(1) через setTimeVarying(false) перед setTimeVarying(true),
        // щоб повторні запуски трекінгу (3-4+ разів поспіль) не накопичували тисячі старих ключів у Premiere Pro
        if (doPos && posProp) {
            try {
                if (typeof posProp.isTimeVarying === "function" && posProp.isTimeVarying()) {
                    posProp.setTimeVarying(false);
                }
            } catch (eClrPos) {}
            try { posProp.setTimeVarying(true); } catch (e) {}
        }
        if (doScale && scaleProp) {
            try {
                if (typeof scaleProp.isTimeVarying === "function" && scaleProp.isTimeVarying()) {
                    scaleProp.setTimeVarying(false);
                }
            } catch (eClrSc) {}
            try { scaleProp.setTimeVarying(true); } catch (e) {}
        }
        if (doRot && rotProp) {
            try {
                if (typeof rotProp.isTimeVarying === "function" && rotProp.isTimeVarying()) {
                    rotProp.setTimeVarying(false);
                }
            } catch (eClrRot) {}
            try { rotProp.setTimeVarying(true); } catch (e) {}
        }

        var firstKfX = (keyframes[0] && isFinite(keyframes[0].x)) ? keyframes[0].x : 0;
        var firstKfY = (keyframes[0] && isFinite(keyframes[0].y)) ? keyframes[0].y : 0;
        var firstKfScale = (keyframes[0] && isFinite(keyframes[0].scale) && keyframes[0].scale > 0) ? keyframes[0].scale : 100;
        var firstKfRot   = (keyframes[0] && keyframes[0].rotation !== undefined && isFinite(keyframes[0].rotation)) ? keyframes[0].rotation : 0;
        var useRelative = (params.relativeOffset !== false);

        var initOffX = initLayerX - (firstKfX * scaleRatioX);
        var initOffY = initLayerY - (firstKfY * scaleRatioY);

        var setScaleWithFallback = function(prop, keyVal, sNum, lastFlag) {
            try {
                prop.setValueAtKey(keyVal, sNum, lastFlag);
                return true;
            } catch (e1) {
                try {
                    prop.setValueAtKey(keyVal, [sNum, sNum], lastFlag);
                    return true;
                } catch (e2) {
                    return false;
                }
            }
        };

        // Кліповий таймінг
        var clipStartSec = 0;
        var clipInSec    = 0;
        var clipInTicks  = "0";
        try { if (clip.start) clipStartSec = clip.start.seconds; } catch (eSt) {}
        try {
            if (clip.inPoint) {
                clipInSec = clip.inPoint.seconds;
                if (clip.inPoint.ticks) clipInTicks = String(clip.inPoint.ticks);
            }
        } catch (eIn2) {}

        var tickRate = 254016000000;
        var baseInTicksNum = parseFloat(clipInTicks) || Math.round(clipInSec * tickRate);

        var firstError = null;
        var count = 0;
        var reusableTime = null;
        try { reusableTime = new Time(); } catch (eInitTime) { reusableTime = null; }

        for (var k = 0; k < keyframes.length; k++) {
            var kf = keyframes[k];
            var isLast = (k === keyframes.length - 1);
            try {
                var kfX = (kf && isFinite(kf.x)) ? kf.x : firstKfX;
                var kfY = (kf && isFinite(kf.y)) ? kf.y : firstKfY;

                var offsetSec = kf.time - clipStartSec;
                var clipLocalSec = clipInSec + offsetSec;
                if (clipLocalSec < 0) clipLocalSec = 0;

                var kfTicks = String(Math.round(baseInTicksNum + (offsetSec * tickRate)));

                var t = reusableTime;
                if (t) {
                    try {
                        t.seconds = clipLocalSec;
                        try { t.ticks = kfTicks; } catch (eTk) {}
                    } catch (eTime) {
                        t = null;
                    }
                }

                // 1. Обертання (Rotation)
                var kfRot = (kf.rotation !== undefined && !isNaN(kf.rotation)) ? (kf.rotation - firstKfRot) : 0;
                var targetRot = 0;
                if (applyMode === 'center') {
                    targetRot = initLayerRot - kfRot;
                } else {
                    targetRot = useRelative ? (initLayerRot + kfRot) : kfRot;
                }
                targetRot = Math.round(targetRot * 100) / 100;

                // 2. Масштаб (Scale)
                var currentKfScale = (kf.scale !== undefined && isFinite(kf.scale) && kf.scale > 0) ? kf.scale : firstKfScale;
                var scRatio = (firstKfScale > 0) ? (currentKfScale / firstKfScale) : 1;
                if (scRatio < 0.1) scRatio = 0.1;
                if (scRatio > 10.0) scRatio = 10.0;

                var targetScale = initLayerScale;
                if (applyMode === 'center') {
                    targetScale = initLayerScale / scRatio;
                    if (targetScale < 1.0) targetScale = 1.0;
                    if (targetScale > 1000.0) targetScale = 1000.0;
                } else {
                    targetScale = useRelative ? (initLayerScale * scRatio) : currentKfScale;
                    if (targetScale < 1.0) targetScale = 1.0;
                    if (targetScale > 10000.0) targetScale = 10000.0;
                }
                targetScale = Math.round(targetScale * 100) / 100;

                // 3. Позиція (Position)
                var targetX = 0;
                var targetY = 0;
                if (applyMode === 'center') {
                    // Режим центрування на об'єкті (Lock-on Center / Стабілізація на об'єкті):
                    // Відео зміщується так, щоб обрана точка завжди залишалася точно по центру кадру секвенції (seqW / 2, seqH / 2)
                    // з урахуванням поточного масштабу, обертання та точки прив'язки (Anchor Point)
                    var activeScale = (doScale && scaleProp) ? (targetScale / 100) : (initLayerScale / 100);
                    var activeRot   = (doRot && rotProp) ? targetRot : initLayerRot;
                    var rotRad = (activeRot * Math.PI) / 180;
                    var cosR = Math.cos(rotRad);
                    var sinR = Math.sin(rotRad);

                    var dx = (kfX - initAnchorX) * scaleRatioX;
                    var dy = (kfY - initAnchorY) * scaleRatioY;

                    var xPrime = activeScale * (dx * cosR - dy * sinR);
                    var yPrime = activeScale * (dx * sinR + dy * cosR);

                    targetX = (seqW / 2) - xPrime;
                    targetY = (seqH / 2) - yPrime;
                } else {
                    if (useRelative) {
                        // ATTACH-режим: шар слідує за точкою трекера.
                        // Масштабує та обертає початковий вектор зміщення (захист від вильоту тексту)
                        var activeScRatio = (doScale && scaleProp) ? scRatio : 1.0;
                        var activeKfRot = (doRot && rotProp) ? kfRot : 0;
                        var rotRadA = (activeKfRot * Math.PI) / 180;
                        var cosRA = Math.cos(rotRadA);
                        var sinRA = Math.sin(rotRadA);

                        var scaledRotOffX = activeScRatio * (cosRA * initOffX - sinRA * initOffY);
                        var scaledRotOffY = activeScRatio * (sinRA * initOffX + cosRA * initOffY);

                        targetX = (kf.x * scaleRatioX) + scaledRotOffX;
                        targetY = (kf.y * scaleRatioY) + scaledRotOffY;
                    } else {
                        targetX = (kf.x * scaleRatioX);
                        targetY = (kf.y * scaleRatioY);
                    }
                }
                var outX = 0;
                var outY = 0;
                if (originalIsNormalized) {
                    outX = Math.round((targetX / seqW) * 100000) / 100000;
                    outY = Math.round((targetY / seqH) * 100000) / 100000;
                } else {
                    outX = Math.round(targetX * 100) / 100;
                    outY = Math.round(targetY * 100) / 100;
                }

                // Запис позиції
                if (doPos && posProp) {
                    var posAdded = false;
                    if (t) {
                        try {
                            posProp.addKey(t);
                            posProp.setValueAtKey(t, [outX, outY], isLast);
                            posAdded = true;
                        } catch (eT) {}
                    }
                    if (!posAdded) {
                        try {
                            posProp.addKey(clipLocalSec);
                            posProp.setValueAtKey(clipLocalSec, [outX, outY], isLast);
                            posAdded = true;
                        } catch (eSec) {
                            try {
                                posProp.addKey(kf.time);
                                posProp.setValueAtKey(kf.time, [outX, outY], isLast);
                                posAdded = true;
                            } catch (eKf) {
                                if (!firstError) firstError = "Pos: " + String(eKf.message || eKf);
                            }
                        }
                    }
                }

                // Запис масштабу
                if (doScale && scaleProp) {
                    var scaleAdded = false;

                    if (t) {
                        try {
                            scaleProp.addKey(t);
                            if (setScaleWithFallback(scaleProp, t, targetScale, isLast)) {
                                scaleAdded = true;
                            }
                        } catch (eTSc) {}
                    }
                    if (!scaleAdded) {
                        try {
                            scaleProp.addKey(clipLocalSec);
                            if (setScaleWithFallback(scaleProp, clipLocalSec, targetScale, isLast)) {
                                scaleAdded = true;
                            }
                        } catch (eSecSc) {
                            try {
                                scaleProp.addKey(kf.time);
                                if (setScaleWithFallback(scaleProp, kf.time, targetScale, isLast)) {
                                    scaleAdded = true;
                                }
                            } catch (eKfSc) {
                                if (!firstError) firstError = "Scale: " + String(eKfSc.message || eKfSc);
                            }
                        }
                    }
                }

                // Запис обертання
                if (doRot && rotProp) {
                    var rotAdded = false;
                    if (t) {
                        try {
                            rotProp.addKey(t);
                            rotProp.setValueAtKey(t, targetRot, isLast);
                            rotAdded = true;
                        } catch (eTRot) {}
                    }
                    if (!rotAdded) {
                        try {
                            rotProp.addKey(clipLocalSec);
                            rotProp.setValueAtKey(clipLocalSec, targetRot, isLast);
                            rotAdded = true;
                        } catch (eSecRot) {
                            try {
                                rotProp.addKey(kf.time);
                                rotProp.setValueAtKey(kf.time, targetRot, isLast);
                                rotAdded = true;
                            } catch (eKfRot) {
                                if (!firstError) firstError = "Rotation: " + String(eKfRot.message || eKfRot);
                            }
                        }
                    }
                }

                count++;
            } catch (eLoop) {
                if (!firstError) firstError = "Loop: " + String(eLoop.message || eLoop);
            }
        }

        // Перевірка збережених ключів (тільки для активних властивостей)
        var posKeysCount = 0;
        var pk = null;
        if (doPos && posProp) {
            try {
                pk = posProp.getKeys();
                if (pk) posKeysCount = pk.length;
            } catch (eK) {}
        }

        var scaleKeysCount = 0;
        if (doScale && scaleProp) {
            try {
                var sk = scaleProp.getKeys();
                if (sk) scaleKeysCount = sk.length;
                sk = null;
            } catch (eK2) {}
        }

        var rotKeysCount = 0;
        if (doRot && rotProp) {
            try {
                var rk = rotProp.getKeys();
                if (rk) rotKeysCount = rk.length;
                rk = null;
            } catch (eK3) {}
        }

        var posVerified = !doPos || !posProp || (typeof posProp.getKeys !== "function") || (posKeysCount > 0);
        var scaleVerified = !doScale || !scaleProp || (typeof scaleProp.getKeys !== "function") || (scaleKeysCount > 0);
        var rotVerified = !doRot || !rotProp || (typeof rotProp.getKeys !== "function") || (rotKeysCount > 0);

        if (!posVerified || !scaleVerified || !rotVerified || count === 0) {
            pk = null;
            reusableTime = null;
            try { $.gc(); } catch (eGcErr) {}
            if (isStill) {
                return _err("STILL_IMAGE_NEST_REQUIRED", "Premiere Pro блокує створення ключів для прямих картинок (.png/.jpg). Будь ласка, натисніть правою кнопкою на шар на таймлайні -> 'Вкладений епізод...' (Nest) і повторіть трекінг.");
            }
            return _err("KEYS_NOT_RECORDED", firstError || "Ключові кадри не збереглися на таймлайні.");
        }

        var firstPosVal = null;
        var lastPosVal  = null;
        try {
            if (pk && pk.length > 0) {
                firstPosVal = posProp.getValueAtKey(pk[0]);
                lastPosVal  = posProp.getValueAtKey(pk[pk.length - 1]);
            }
        } catch (eDbg) {}

        var targetClipNameOut = clip.name;
        pk = null;
        reusableTime = null;
        keyframes = null;
        params = null;
        try { $.gc(); } catch (eGc) {}

        return _v({
            success:        true,
            targetClipName: targetClipNameOut,
            trackIndex:     trackIndex,
            count:          Math.max(posKeysCount, scaleKeysCount, rotKeysCount, count),
            posKeys:        posKeysCount,
            scaleKeys:      scaleKeysCount,
            rotKeys:        rotKeysCount,
            firstPosVal:    firstPosVal,
            lastPosVal:     lastPosVal
        });

    } catch (e) {
        return _err("EX_APPLY_KEYFRAMES", String(e));
    }
}

function getSequenceSettings() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return _err("NO_SEQUENCE");

        var fps = 25;
        var width = 1920;
        var height = 1080;
        try {
            var settings = seq.getSettings();
            if (settings && settings.videoFrameRate && settings.videoFrameRate.ticks) {
                var sTicks = parseFloat(settings.videoFrameRate.ticks);
                if (sTicks > 0) {
                    fps = 254016000000 / sTicks;
                }
            }
            if (isNaN(fps) || !isFinite(fps) || fps <= 0) fps = 25;
            if (settings && settings.videoFrameWidth) width = settings.videoFrameWidth;
            if (settings && settings.videoFrameHeight) height = settings.videoFrameHeight;
        } catch (eSettings) { fps = 25; }

        return _v({
            name:   seq.name || "Sequence",
            fps:    fps,
            width:  width,
            height: height
        });

    } catch (e) {
        return _err("EX_SETTINGS", String(e));
    }
}

// Global and $ export
try {
    $.getSelectedClipInfo  = getSelectedClipInfo;
    $.getSelectedLayerInfo = getSelectedLayerInfo;
    $.getPlayheadTime      = getPlayheadTime;
    $.applyKeyframesToClip = applyKeyframesToClip;
    $.getSequenceSettings  = getSequenceSettings;
} catch (e) {}

"AutoTracker HostScript Loaded";
